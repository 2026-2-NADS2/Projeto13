// Barreira: um "tijolinho" dos escudos que protegem o jogador.
// Herda de Entidade (posição, tamanho, colisão) e acrescenta a ideia
// de RESISTÊNCIA: cada tiro tira 1 ponto, e com 0 o pedaço some.
// Vários pedaços juntos formam um escudo no formato clássico do Space Invaders.
class Barreira extends Entidade {
  constructor(x, y) {
    super(x, y, Barreira.TAMANHO, Barreira.TAMANHO, '#33ccff');
    this.resistencia = 3; // aguenta 3 tiros antes de sumir
  }

  // Chamado quando um tiro (do jogador ou do inimigo) acerta este pedaço.
  receberDano() {
    this.resistencia--;
    if (this.resistencia <= 0) {
      this.ativo = false; // o Jogo remove pedaços inativos da lista
    }
  }

  // Sobrescreve desenhar() da Entidade (POLIMORFISMO): em vez de uma cor fixa,
  // o pedaço fica mais escuro conforme vai sendo danificado.
  desenhar(ctx) {
    const coresPorResistencia = { 3: '#33ccff', 2: '#2389ad', 1: '#174f63' };
    ctx.fillStyle = coresPorResistencia[this.resistencia];
    ctx.fillRect(this.x, this.y, this.largura, this.altura);
  }

  // Método estático: pertence à CLASSE, não a um pedaço específico.
  // Monta um escudo inteiro a partir de um "desenho" em texto,
  // onde '#' vira um pedaço de barreira e '.' fica vazio.
  static criarEscudo(xInicial, yInicial) {
    // Desenho original (a "boca" do escudo fica embaixo, de frente para o jogador)...
    const formatoOriginal = [
      '..######..',
      '.########.',
      '##########',
      '##########',
      '###....###',
      '##......##',
    ];
    // ...girado 90° para a "boca" ficar do lado ESQUERDO, de frente para o jogador.
    const formato = Sprites.girar(formatoOriginal, 'horario');

    const pedacos = [];
    formato.forEach((linha, l) => {
      [...linha].forEach((caractere, c) => {
        if (caractere === '#') {
          const x = xInicial + c * Barreira.TAMANHO;
          const y = yInicial + l * Barreira.TAMANHO;
          pedacos.push(new Barreira(x, y));
        }
      });
    });
    return pedacos;
  }
}

// Tamanho (em pixels) de cada pedaço quadrado da barreira.
Barreira.TAMANHO = 8;
