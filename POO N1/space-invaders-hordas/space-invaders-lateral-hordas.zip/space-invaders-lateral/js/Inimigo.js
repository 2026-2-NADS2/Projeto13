// Inimigo é a classe base para todos os tipos de invasor.
// Ela guarda o que é comum (movimento em bloco, pontos, vida)
// e deixa o comportamento específico (atualizar / atirar) para as
// subclasses sobrescreverem -> é aqui que o POLIMORFISMO acontece:
// o Jogo trata todo mundo como "Inimigo", mas cada um se comporta diferente.
//
// Versão LATERAL: o bloco de inimigos sobe e desce na tela e, a cada vez que
// encosta no topo ou no chão, avança um passo para a esquerda (em direção ao jogador).
class Inimigo extends Entidade {
  constructor(x, y, largura, altura, cor, pontos) {
    super(x, y, largura, altura, cor);
    this.pontos = pontos;
    this.direcao = 1; // 1 = para baixo, -1 = para cima (movimento em bloco)
    this.quadros = null; // desenhos do inimigo (Sprites); cada subclasse escolhe os seus
  }

  // O inimigo "anda": alterna entre os 2 quadros do desenho conforme se desloca.
  quadroAtual() {
    return Math.floor(Math.abs(this.y) / 10) % 2;
  }

  // Sobrescreve desenhar() da Entidade: em vez de um retângulo, desenha o alien
  // da subclasse (lula, caranguejo ou polvo) -> POLIMORFISMO pelos dados de cada filha.
  desenhar(ctx) {
    Sprites.desenhar(ctx, this.quadros[this.quadroAtual()], this.x, this.y, this.largura, this.altura, this.cor);
  }

  // Comportamento padrão de movimento em bloco (usado como base;
  // as subclasses podem sobrescrever para se mover de outro jeito).
  mover(velocidadeBase) {
    this.y += velocidadeBase * this.direcao;

    // Se bateu no topo ou no chão, quem chama esse método decide inverter a direção
    // e avançar o bloco todo (isso fica no Jogo.js, pois afeta o grupo inteiro).
  }

  // Método "gancho" que cada subclasse pode sobrescrever para atirar
  // com sua própria lógica/chance. Por padrão, um inimigo comum não atira.
  tentarAtirar(listaProjeteis) {
    // Implementação vazia: nem todo inimigo atira.
  }
}
