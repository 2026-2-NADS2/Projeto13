// Classe Jogo: orquestra tudo. Não sabe (nem precisa saber) o tipo
// exato de cada inimigo -- trata todos como "Inimigo" e chama os
// mesmos métodos (mover, tentarAtirar, desenhar). Cada um responde
// à sua própria maneira. Isso é polimorfismo em ação.
//
// VERSÃO LATERAL (shooter de rolagem lateral, como Gradius / R-Type):
// o jogador fica à esquerda e se move nos 4 sentidos; os invasores vêm da
// direita, sobem e descem em bloco e avançam um passo a cada vez que
// encostam no topo ou no chão. A tela acompanha o tamanho da janela.
//
// HORDAS: a partida tem 5 hordas (ondas) de invasores, cada uma maior que a anterior.
// Ao destruir todos os invasores de uma horda, começa a próxima; a vitória só vem
// depois da última. A cada horda as vidas voltam para 3, mas o estrago nos escudos continua.
//
// O jogo tem 4 momentos: tela de início -> jogando (-> pausado) -> tela de fim
// (vitória ou derrota), de onde dá para reiniciar sem recarregar a página.
class Jogo {
  constructor() {
    this.canvas = document.getElementById('canvas');
    this.ctx = this.canvas.getContext('2d');
    this.areaJogo = document.querySelector('.area-jogo'); // caixa que ocupa o espaço livre da janela

    this.teclas = {};
    this.rodando = false; // false = jogo parado (início ou fim)
    this.pausado = false; // true = partida em andamento, mas congelada pelo jogador
    this.idFrame = null;  // guarda o id do requestAnimationFrame para poder cancelar

    // Passo fixo: as regras do jogo rodam SEMPRE 60 vezes por segundo,
    // não importa se o monitor é de 60, 120 ou 144 Hz.
    this.passo = 1000 / 60;   // duração de 1 atualização, em milissegundos
    this.tempoAcumulado = 0;  // tempo real que ainda falta "simular"
    this.ultimoTempo = 0;     // momento do quadro anterior

    // A Tela recebe a ação a executar quando o botão for clicado: iniciar o jogo.
    this.tela = new Tela(() => this._aoClicarNaTela());

    // Botão de pausa do HUD
    this.botaoPausa = document.getElementById('botao-pausa');
    this.botaoPausa.addEventListener('click', () => {
      this.alternarPausa();
      this.botaoPausa.blur(); // evita que a barra de espaço "aperte" o botão sem querer
    });

    // Pausa automática ao trocar de aba, para não perder vidas sem querer
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) this.pausar();
    });

    // Se a janela mudar de tamanho com o jogo parado, refaz o cenário para ocupar a tela.
    // Durante a partida o CSS só escala a imagem (sem deformar), e o novo tamanho
    // passa a valer na próxima partida.
    window.addEventListener('resize', () => {
      if (this.rodando) return;
      this._ajustarTamanho();
      this._resetarEstado();
      this._desenhar();
    });

    this._loop = this._loop.bind(this);
    this._configurarTeclado();

    // Monta os objetos e desenha o primeiro quadro por trás da tela de início,
    // mas NÃO começa o loop: o jogador precisa clicar em "Iniciar".
    this._ajustarTamanho();
    this._resetarEstado();
    this._desenhar();
    this.tela.mostrarInicio();
  }

  // Define o tamanho do "mundo" do jogo: altura fixa (720) e largura proporcional
  // ao formato da janela. Assim a dificuldade é igual em qualquer monitor
  // e o jogo aproveita a tela inteira, sem faixas pretas nas laterais.
  _ajustarTamanho() {
    const proporcao = this.areaJogo.clientWidth / this.areaJogo.clientHeight;
    const largura = Math.round(Jogo.ALTURA_MUNDO * proporcao);
    this.canvas.height = Jogo.ALTURA_MUNDO;
    this.canvas.width = Math.min(Math.max(largura, Jogo.LARGURA_MINIMA), Jogo.LARGURA_MAXIMA);
  }

  // Cria tudo do zero. Usado na primeira partida e em cada reinício,
  // garantindo que nada da partida anterior fique para trás.
  _resetarEstado() {
    this.jogador = new Jogador(40, 0);
    this.jogador.y = (this.canvas.height - this.jogador.altura) / 2; // começa no meio da altura
    this.inimigos = [];
    this.projeteisJogador = [];
    this.projeteisInimigo = [];
    this.barreiras = this._criarBarreiras();

    this.pontos = 0;
    this.velocidadeBaseInimigos = 1;
    this.direcaoBloco = 1; // 1 = bloco descendo, -1 = subindo
    this.teclas = {}; // evita "tecla presa" vinda da partida anterior

    this.horda = 1;         // número da horda atual (1 a Jogo.HORDAS.length)
    this.quadrosDeAviso = 0; // > 0 = mostrando o aviso "HORDA N" (o jogo espera)

    this._criarOnda();
  }

  // Chamado quando a horda atual é destruída: monta a próxima.
  // As vidas voltam para 3 e a nave volta para a posição inicial,
  // mas os escudos NÃO são recriados (o estrago acumula).
  _proximaHorda() {
    this.horda++;
    this.jogador = new Jogador(40, 0); // jogador novo = 3 vidas e sem cooldown
    this.jogador.y = (this.canvas.height - this.jogador.altura) / 2;
    this.projeteisJogador = [];
    this.projeteisInimigo = [];
    this.direcaoBloco = 1;
    this._criarOnda();
    this._mostrarAvisoDeHorda();
  }

  // Mostra "HORDA N" por um instante antes de a horda começar a se mover.
  _mostrarAvisoDeHorda() {
    this.quadrosDeAviso = Jogo.QUADROS_DE_AVISO;
    this.tela.mostrarHorda(this.horda, Jogo.HORDAS.length);
  }

  // Começa (ou recomeça) a partida. Chamado pelo botão da Tela ou pela tecla Enter.
  iniciar() {
    if (this.rodando) return; // evita iniciar duas vezes e criar dois loops

    this._ajustarTamanho(); // aproveita o tamanho atual da janela
    this._resetarEstado();
    this._mostrarAvisoDeHorda(); // a partida começa com o aviso "HORDA 1"
    this.rodando = true;
    this.tempoAcumulado = 0;
    this.ultimoTempo = performance.now();
    this.idFrame = requestAnimationFrame(this._loop);
  }

  // Clique no botão da Tela: continua o jogo se estiver pausado, senão inicia/reinicia.
  _aoClicarNaTela() {
    if (this.pausado) {
      this.continuar();
    } else {
      this.iniciar();
    }
  }

  // Pausa: congela a partida (cancela o loop) e mostra a tela de pausa.
  pausar() {
    if (!this.rodando || this.pausado) return;

    this.pausado = true;
    cancelAnimationFrame(this.idFrame);
    this.tela.mostrarPausa();
    this.botaoPausa.textContent = 'Continuar (P)';
  }

  // Continua de onde parou. Zera o relógio para o tempo parado não ser "simulado".
  continuar() {
    if (!this.pausado) return;

    this.pausado = false;
    // Se a pausa aconteceu durante o aviso de horda, o aviso volta; senão, a tela some.
    if (this.quadrosDeAviso > 0) {
      this.tela.mostrarHorda(this.horda, Jogo.HORDAS.length);
    } else {
      this.tela.esconder();
    }
    this.botaoPausa.textContent = 'Pausar (P)';
    this.tempoAcumulado = 0;
    this.ultimoTempo = performance.now();
    this.idFrame = requestAnimationFrame(this._loop);
  }

  alternarPausa() {
    if (this.pausado) {
      this.continuar();
    } else {
      this.pausar();
    }
  }

  // Traduz a tecla apertada para o "nome" que o jogo usa.
  // As setas viram a letra equivalente do WASD (↑ = W, ← = A, ↓ = S, → = D),
  // então setas e WASD passam pelo MESMO caminho e se comportam igual.
  // Usa e.key para as setas porque ele vale também para as setas do teclado
  // numérico; para as outras teclas usa e.code (posição física da tecla).
  _nomeDaTecla(e) {
    return Jogo.SETAS_PARA_WASD[e.key] || e.code;
  }

  _configurarTeclado() {
    window.addEventListener('keydown', (e) => {
      // Impede que setas e espaço rolem a página enquanto se joga
      if (e.code === 'Space' || Jogo.SETAS_PARA_WASD[e.key]) {
        e.preventDefault();
      }

      // P ou Esc pausam e continuam a partida
      if ((e.code === 'KeyP' || e.code === 'Escape') && !e.repeat) {
        this.alternarPausa();
        return;
      }

      // Enter inicia ou reinicia quando o jogo está parado
      if (e.code === 'Enter' && !this.rodando) {
        this.iniciar();
        return;
      }

      this.teclas[this._nomeDaTecla(e)] = true;
    });
    window.addEventListener('keyup', (e) => (this.teclas[this._nomeDaTecla(e)] = false));
  }

  // Monta o bloco de inimigos da horda atual em COLUNAS, misturando os 3 tipos.
  // A tabela Jogo.HORDAS diz quantos inimigos vão em cada coluna e qual o tipo de
  // cada coluna, da direita para a esquerda: A = atirador, R = rápido, B = básico.
  _criarOnda() {
    const { colunas, porColuna } = Jogo.HORDAS[this.horda - 1];
    const tipoDaLetra = { A: InimigoAtirador, R: InimigoRapido, B: InimigoBasico };
    const espacoHorizontal = 64; // distância entre colunas

    // Distância entre inimigos da mesma coluna: 72, ou menos se a coluna for
    // tão comprida que o bloco ficaria sem espaço (120px) para subir e descer.
    const espacoVertical = Math.min(72, (this.canvas.height - 24 - 120) / (porColuna - 1));

    // centraliza o bloco na altura da tela
    const alturaBloco = (porColuna - 1) * espacoVertical + 24;
    const yInicial = (this.canvas.height - alturaBloco) / 2;

    for (let c = 0; c < colunas.length; c++) {
      const Tipo = tipoDaLetra[colunas[c]];
      const x = this.canvas.width - 90 - c * espacoHorizontal;
      for (let i = 0; i < porColuna; i++) {
        const y = yInicial + i * espacoVertical;
        // new Tipo(...) -> cada coluna instancia uma subclasse diferente,
        // mas todas acabam guardadas na mesma lista "this.inimigos".
        this.inimigos.push(new Tipo(x, y));
      }
    }
  }

  // Cria 4 escudos espaçados igualmente na vertical, logo à frente do jogador.
  // Cada escudo é uma lista de pedaços (Barreira); juntamos todos numa lista só.
  _criarBarreiras() {
    const alturaEscudo = 10 * Barreira.TAMANHO; // o desenho girado tem 10 linhas
    const quantidade = 4;
    const espaco = this.canvas.height / quantidade;
    const x = 130;
    let pedacos = [];

    for (let i = 0; i < quantidade; i++) {
      // centraliza cada escudo dentro do seu quarto da altura
      const y = espaco * i + (espaco - alturaEscudo) / 2;
      pedacos = pedacos.concat(Barreira.criarEscudo(x, y));
    }
    return pedacos;
  }

  // Lê o teclado: WASD (ou as setas, já traduzidas para WASD) para mover
  // nos 4 sentidos, espaço para atirar.
  _tratarInput() {
    const t = this.teclas;
    const direcaoX = (t['KeyD'] ? 1 : 0) - (t['KeyA'] ? 1 : 0); // D = direita, A = esquerda
    const direcaoY = (t['KeyS'] ? 1 : 0) - (t['KeyW'] ? 1 : 0); // S = baixo,   W = cima

    if (direcaoX !== 0 || direcaoY !== 0) {
      const j = this.jogador;
      const xAntes = j.x;
      const yAntes = j.y;
      j.mover(direcaoX, direcaoY, this.canvas.width, this.canvas.height);
      this._impedirEntrarNoEscudo(xAntes, yAntes);
    }
    if (t['Space']) this.jogador.atirar(this.projeteisJogador);
  }

  // O escudo funciona como uma parede para a nave: ela não pode entrar nele.
  // Se o movimento fez a nave encostar num pedaço de escudo, tentamos manter
  // só uma das direções (assim ela "desliza" pela borda do escudo, como numa parede);
  // se nem assim der, ela volta para onde estava antes do movimento.
  _impedirEntrarNoEscudo(xAntes, yAntes) {
    const j = this.jogador;
    if (!this._jogadorNoEscudo()) return;

    const xNovo = j.x;
    const yNovo = j.y;

    j.x = xAntes;                     // 1ª tentativa: anda só na vertical
    if (!this._jogadorNoEscudo()) return;

    j.x = xNovo;                      // 2ª tentativa: anda só na horizontal
    j.y = yAntes;
    if (!this._jogadorNoEscudo()) return;

    j.x = xAntes;                     // não dá para andar: fica parado
    j.y = yAntes;
  }

  // true se a nave está encostando em algum pedaço de escudo
  _jogadorNoEscudo() {
    return this.barreiras.some((pedaco) => pedaco.colideCom(this.jogador));
  }

  _atualizarInimigos() {
    let bateuNaBorda = false;

    this.inimigos.forEach((inimigo) => {
      inimigo.direcao = this.direcaoBloco;
      // Chamada polimórfica: cada tipo de inimigo se move do seu jeito.
      inimigo.mover(this.velocidadeBaseInimigos);
      inimigo.tentarAtirar(this.projeteisInimigo);

      if (inimigo.y <= 0 || inimigo.y + inimigo.altura >= this.canvas.height) {
        bateuNaBorda = true;
      }
    });

    // Se algum inimigo bateu no topo ou no chão, o bloco todo avança para a
    // esquerda (rumo ao jogador) e inverte a direção vertical.
    if (bateuNaBorda) {
      this.direcaoBloco *= -1;
      this.inimigos.forEach((inimigo) => (inimigo.x -= Jogo.AVANCO_DO_BLOCO));
    }
  }

  _atualizarProjeteis() {
    const larguraCanvas = this.canvas.width;
    [...this.projeteisJogador, ...this.projeteisInimigo].forEach((p) => p.atualizar(larguraCanvas));
    this.projeteisJogador = this.projeteisJogador.filter((p) => p.ativo);
    this.projeteisInimigo = this.projeteisInimigo.filter((p) => p.ativo);
  }

  _verificarColisoes() {
    // Tiros (do jogador E dos inimigos) x barreiras: o escudo segura o tiro
    // e perde resistência, como no Space Invaders original.
    // A nave começa no vão entre dois escudos, então consegue atirar desde o início.
    [...this.projeteisJogador, ...this.projeteisInimigo].forEach((projetil) => {
      for (const pedaco of this.barreiras) {
        if (projetil.ativo && pedaco.ativo && projetil.colideCom(pedaco)) {
          projetil.ativo = false;
          pedaco.receberDano();
          break; // um tiro só acerta um pedaço
        }
      }
    });

    // Inimigo que avança até o escudo vai "atropelando" os pedaços
    this.inimigos.forEach((inimigo) => {
      this.barreiras.forEach((pedaco) => {
        if (pedaco.ativo && inimigo.colideCom(pedaco)) {
          pedaco.ativo = false;
        }
      });
    });
    this.barreiras = this.barreiras.filter((b) => b.ativo);

    // Tiro do jogador x inimigos
    this.projeteisJogador.forEach((projetil) => {
      this.inimigos.forEach((inimigo) => {
        if (projetil.ativo && inimigo.ativo && projetil.colideCom(inimigo)) {
          projetil.ativo = false;
          inimigo.ativo = false;
          this.pontos += inimigo.pontos;
        }
      });
    });

    // Inimigo x jogador: como agora o jogador anda pela tela toda, bater de frente
    // num invasor custa uma vida (e o invasor é destruído no choque).
    this.inimigos.forEach((inimigo) => {
      if (inimigo.ativo && inimigo.colideCom(this.jogador)) {
        inimigo.ativo = false;
        this.jogador.vidas--;
      }
    });
    this.inimigos = this.inimigos.filter((i) => i.ativo);
    this.projeteisJogador = this.projeteisJogador.filter((p) => p.ativo);

    // Tiro do inimigo x jogador
    this.projeteisInimigo.forEach((projetil) => {
      if (projetil.ativo && projetil.colideCom(this.jogador)) {
        projetil.ativo = false;
        this.jogador.vidas--;
      }
    });
    this.projeteisInimigo = this.projeteisInimigo.filter((p) => p.ativo);
  }

  _verificarFimDeJogo() {
    const total = Jogo.HORDAS.length;
    if (this.jogador.vidas <= 0) {
      this._finalizar(false, `Suas vidas acabaram na horda ${this.horda} de ${total}.`);
    } else if (this.inimigos.length === 0) {
      // Horda destruída: ainda falta alguma? Então vem a próxima. Senão, vitória.
      if (this.horda < total) {
        this._proximaHorda();
      } else {
        this._finalizar(true, `Você sobreviveu às ${total} hordas de invasores. Parabéns!`);
      }
    } else if (this.inimigos.some((i) => i.x <= 0)) {
      // Um invasor chegou à borda esquerda: passou pela defesa.
      this._finalizar(false, `Os invasores passaram pela sua defesa na horda ${this.horda} de ${total}.`);
    }
  }

  // Para o jogo e mostra a tela de fim com o botão de reiniciar.
  _finalizar(venceu, motivo) {
    this.rodando = false;
    this.pausado = false;
    this.quadrosDeAviso = 0;
    this.botaoPausa.textContent = 'Pausar (P)';
    cancelAnimationFrame(this.idFrame);
    this.tela.mostrarFim(venceu, motivo, this.pontos);
  }

  _desenhar() {
    const ctx = this.ctx;
    ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

    this.barreiras.forEach((b) => b.desenhar(ctx));
    this.jogador.desenhar(ctx);
    this.inimigos.forEach((i) => i.desenhar(ctx));
    this.projeteisJogador.forEach((p) => p.desenhar(ctx));
    this.projeteisInimigo.forEach((p) => p.desenhar(ctx));

    document.getElementById('pontos').textContent = `Pontos: ${this.pontos}`;
    document.getElementById('vidas').textContent = `Vidas: ${this.jogador.vidas}`;
    document.getElementById('horda').textContent = `Horda: ${this.horda}/${Jogo.HORDAS.length}`;
  }

  // Uma "rodada" das regras do jogo (equivale a 1/60 de segundo).
  _atualizar() {
    // Durante o aviso "HORDA N" nada se mexe; quando o tempo acaba, o aviso some.
    if (this.quadrosDeAviso > 0) {
      this.quadrosDeAviso--;
      if (this.quadrosDeAviso === 0) this.tela.esconder();
      return;
    }

    this._tratarInput();
    this.jogador.atualizar();
    this._atualizarInimigos();
    this._atualizarProjeteis();
    this._verificarColisoes();
    this._verificarFimDeJogo();
  }

  // O navegador chama o _loop no ritmo do monitor e informa o horário atual.
  // Somamos o tempo que passou e rodamos _atualizar() quantas vezes couberem:
  // monitor de 60 Hz -> ~1 vez por quadro; 144 Hz -> às vezes 0, às vezes 1.
  // Assim a velocidade do jogo fica igual em qualquer computador.
  _loop(agora) {
    if (!this.rodando || this.pausado) return;

    // Limita a 250 ms para o jogo não "pular" se a aba ficou em segundo plano
    this.tempoAcumulado += Math.min(agora - this.ultimoTempo, 250);
    this.ultimoTempo = agora;

    while (this.tempoAcumulado >= this.passo && this.rodando) {
      this._atualizar();
      this.tempoAcumulado -= this.passo;
    }

    this._desenhar(); // desenha o último quadro mesmo quando o jogo acabou

    // Só pede o próximo quadro se o jogo continua rodando
    if (this.rodando) {
      this.idFrame = requestAnimationFrame(this._loop);
    }
  }
}

// Constantes do "mundo" do jogo (em pixels do canvas).
Jogo.ALTURA_MUNDO = 720;     // altura fixa; a largura se ajusta ao formato da janela
Jogo.LARGURA_MINIMA = 960;   // janelas "quadradas" demais ganham faixas pretas nas laterais
Jogo.LARGURA_MAXIMA = 1680;  // monitores ultrawide: limite para o jogo não ficar fácil demais
Jogo.AVANCO_DO_BLOCO = 48;   // quanto o bloco avança para a esquerda a cada vez que bate no topo/chão

// Cada seta funciona como a letra do WASD que aponta para o mesmo lado.
Jogo.SETAS_PARA_WASD = {
  ArrowUp: 'KeyW',    // ↑ = W (cima)
  ArrowLeft: 'KeyA',  // ← = A (esquerda)
  ArrowDown: 'KeyS',  // ↓ = S (baixo)
  ArrowRight: 'KeyD', // → = D (direita)
};
Jogo.QUADROS_DE_AVISO = 90;  // duração do aviso "HORDA N": 90 atualizações = 1,5 segundo

// As 5 hordas. "colunas" tem uma letra por coluna, da direita para a esquerda:
// A = atirador, R = rápido, B = básico. A cada horda entra mais uma coluna, e quase
// sempre de atiradores, que são os que deixam o jogo difícil. A última dá um salto
// maior (8 colunas de 10) para ser o desafio final.
Jogo.HORDAS = [
  { colunas: 'ARAB',     porColuna: 8 },  // 32 invasores, 16 atiradores
  { colunas: 'ARABA',    porColuna: 8 },  // 40 invasores, 24 atiradores
  { colunas: 'AARABA',   porColuna: 8 },  // 48 invasores, 32 atiradores
  { colunas: 'AARAABA',  porColuna: 8 },  // 56 invasores, 40 atiradores
  { colunas: 'AARAABAA', porColuna: 10 }, // 80 invasores, 60 atiradores
];

// Cria o jogo quando a página carrega. Fica em window.jogo só para facilitar testes no console.
window.addEventListener('load', () => {
  window.jogo = new Jogo();
});
