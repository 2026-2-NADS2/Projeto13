// Inimigo rápido: sobrescreve mover() para se deslocar mais rápido
// que o padrão herdado de Inimigo. Vale mais pontos por ser mais difícil de acertar.
class InimigoRapido extends Inimigo {
  constructor(x, y) {
    super(x, y, 28, 22, '#ffd633', 20);
    this.multiplicadorVelocidade = 2;
    this.quadros = Sprites.CARANGUEJO; // visual do caranguejo
  }

  // Sobrescreve o mover() da classe pai: mesma ideia, porém mais rápido.
  mover(velocidadeBase) {
    this.y += velocidadeBase * this.multiplicadorVelocidade * this.direcao;
  }
}
