// ============================================================
// Descrição: cria o "pool" de conexões com o MySQL e o exporta para
// ser usado pelas rotas (server.js). As credenciais NÃO ficam no
// código: são lidas do arquivo .env, que não vai para o GitHub.
// ============================================================

// Módulo nativo do Node para montar caminhos de arquivos.
const path = require('path');

// Carrega as variáveis do arquivo .env para process.env.
// O "path" aponta para o .env na MESMA pasta deste arquivo. Sem ele,
// o dotenv procuraria o .env na pasta onde o terminal está, e as
// credenciais não seriam encontradas ao rodar o servidor de outra pasta.
require('dotenv').config({ path: path.join(__dirname, '.env') });

// Versão "promise" do driver mysql2: permite usar async/await nas consultas.
const mysql = require('mysql2/promise');

// Pool = conjunto de conexões reaproveitáveis. Em vez de abrir e fechar
// uma conexão a cada consulta, cada rota pega uma livre e devolve depois.
const pool = mysql.createPool({
  host: process.env.DB_HOST,         // endereço do servidor MySQL (ex.: 127.0.0.1)
  port: process.env.DB_PORT,         // porta do MySQL (padrão: 3306)
  user: process.env.DB_USER,         // usuário do banco
  password: process.env.DB_PASSWORD, // senha (só no .env, nunca no código)
  database: process.env.DB_NAME,     // nome do banco (kfka)
  charset: 'utf8mb4',                // garante acentos e "ç" corretos
});

// Exporta o pool para o server.js usar com require('./db').
module.exports = pool;
