// ============================================================
// KFKA - Plataforma de Acompanhamento Escolar
// Arquivo: server.js
// Descrição: ponto de entrada do backend. Cria o servidor Express,
// entrega as páginas do front-end (pasta public), define as rotas
// da API e trata endereços inexistentes (erro 404).
// Para iniciar: node server.js
// ============================================================

// Importa o módulo "path", que já vem com o Node.js. Ele monta
// caminhos de arquivos do jeito certo em qualquer sistema
// operacional (Windows usa "\" e Linux/Mac usam "/").
const path = require('path');

// Importa o Express, o framework que cria o servidor web e as rotas.
const express = require('express');

// Importa o pool de conexões com o MySQL, configurado no arquivo db.js.
// "Pool" é um conjunto de conexões reaproveitáveis: em vez de abrir e
// fechar uma conexão a cada consulta, o sistema pega uma livre do pool.
const pool = require('./db');

// Importa o bcryptjs, usado em POST /api/login para conferir a senha
// digitada contra o hash guardado na coluna usuario.senha_hash.
// Instalação: npm install bcryptjs (já listado no package.json).
const bcrypt = require('bcryptjs');

// Cria a aplicação Express. É nela que registramos as rotas.
const app = express();

// Porta em que o servidor vai "escutar" os pedidos (localhost:3000).
const PORT = 3000;

// ============================================================
// ARQUIVOS ESTÁTICOS (front-end)
// ============================================================

// Entrega automaticamente os arquivos da pasta "public" (HTML, CSS,
// JS, imagens). Exemplo: um pedido para /html/login/login.html devolve
// o arquivo public/html/login/login.html, sem precisar criar uma rota
// para cada página.
// path.join(__dirname, 'public') monta o caminho completo da pasta
// "public" a partir de onde o server.js está. Assim o site funciona
// mesmo que o comando "node server.js" seja rodado de outra pasta.
app.use(express.static(path.join(__dirname, 'public')));

// Faz o Express entender o corpo dos pedidos enviados em JSON (é como
// o public/js/login.js envia e-mail e senha). Sem esta linha,
// req.body chegaria undefined em POST /api/login.
app.use(express.json());

// Abrir http://localhost:3000/ leva direto para a tela de login.
app.get('/', (req, res) => {
  res.redirect('/html/login/login.html');
});

// ============================================================
// ROTAS DA API
// ============================================================

// Rota de teste: confirma se o servidor consegue falar com o banco.
// "async" permite usar "await" para esperar a resposta do MySQL
// sem travar o servidor.
app.get('/teste-db', async (req, res) => {
  try {
    // Conta quantos registros existem na tabela usuario.
    // O resultado vem como [linhas, colunas]; pegamos só as linhas.
    const [rows] = await pool.query('SELECT COUNT(*) AS total FROM usuario');

    // Responde em JSON dizendo que a conexão funcionou e o total encontrado.
    res.json({ conectado: true, total_usuarios: rows[0].total });
  } catch (erro) {
    // Se algo falhar (banco desligado, senha errada no .env etc.),
    // responde com status 500 (erro interno do servidor).
    // Observação: mostrar erro.message é aceitável só nesta rota de
    // teste; em rotas reais isso pode expor detalhes do banco.
    res.status(500).json({ conectado: false, erro: erro.message });
  }
});

// ============================================================
// FUNÇÃO AUXILIAR: lerInteiro
// Os filtros chegam na URL SEMPRE como texto (ex.: "?bimestre=3"
// chega como a string "3"). Esta função converte para número inteiro
// e confere se está dentro do intervalo permitido.
// Devolve:
//   - null      -> o filtro não foi enviado (sem filtro);
//   - um número -> valor válido;
//   - NaN       -> valor inválido (a rota responde erro 400).
// ============================================================
function lerInteiro(valor, minimo, maximo) {
  // Filtro ausente ou vazio ("?bimestre=") = sem filtro.
  if (valor === undefined || valor === '') return null;

  // Number("3") -> 3; Number("abc") -> NaN; Number("2.5") -> 2.5
  const numero = Number(valor);

  // Number.isInteger descarta NaN e números quebrados (2.5).
  if (!Number.isInteger(numero) || numero < minimo || numero > maximo) {
    return NaN;
  }
  return numero;
}

// ============================================================
// GET /api/relatorios
// Lista os relatórios PUBLICADOS, com filtros e paginação.
// Usada pela página html/responsavel/responsavel_relatorios_filtro.html (tabela
// "tabela-relatorios") e pelos "relatórios recentes" do início.
//
// Filtros opcionais na URL (query string):
//   ?aluno=1          -> id do aluno
//   &ano_letivo=2026  -> ano letivo
//   &bimestre=3       -> número do bimestre (1 a 4)
//   &disciplina=Matemática -> nome da disciplina
//   &pagina=2         -> página de resultados (padrão: 1)
// Exemplo: /api/relatorios?aluno=1&bimestre=3&pagina=1
//
// Lê a VIEW vw_relatorio_publicado do schema.sql, que já faz o JOIN
// das 6 tabelas e só traz registros com status = 'publicado'.
//
// ATENÇÃO (segurança/LGPD, para a E2): hoje ainda não existe login
// com sessão, então esta rota devolve relatórios de TODOS os alunos.
// Quando houver sessão, ela deve devolver apenas os alunos vinculados
// ao responsável logado (tabela aluno_responsavel). Sem isso, um pai
// conseguiria ver relatórios dos filhos de outras famílias.
// ============================================================
app.get('/api/relatorios', async (req, res) => {
  // Quantos relatórios por página. Trazer tudo de uma vez deixaria o
  // sistema lento quando houver muitos registros (requisito de
  // desempenho do PI: paginação).
  const POR_PAGINA = 10;

  // ---------- 1. Ler e validar os filtros ----------
  const aluno = lerInteiro(req.query.aluno, 1, 2147483647);
  const anoLetivo = lerInteiro(req.query.ano_letivo, 2000, 2100);
  const bimestre = lerInteiro(req.query.bimestre, 1, 4);
  const pagina = lerInteiro(req.query.pagina, 1, 100000) ?? 1; // ?? = "se for null, use 1"

  // Disciplina é texto: tiramos espaços das pontas e limitamos o tamanho
  // (mesmo limite da coluna disciplina.nome no banco: 100).
  const disciplina = typeof req.query.disciplina === 'string'
    ? req.query.disciplina.trim().slice(0, 100)
    : '';

  // Algum filtro numérico veio inválido? Responde 400 (erro do cliente)
  // com uma mensagem clara, em vez de deixar o banco dar erro.
  if ([aluno, anoLetivo, bimestre, pagina].some(Number.isNaN)) {
    return res.status(400).json({
      erro: 'Filtro inválido. Verifique aluno, ano letivo, bimestre (1 a 4) e página.',
    });
  }

  // ---------- 2. Montar o WHERE só com os filtros enviados ----------
  // "condicoes" guarda os pedaços do WHERE; "valores" guarda os dados,
  // na mesma ordem dos "?". O mysql2 troca cada "?" pelo valor com
  // segurança: isso impede SQL Injection. NUNCA junte o valor do
  // usuário direto no texto do SQL.
  const condicoes = [];
  const valores = [];

  if (aluno !== null) {
    condicoes.push('aluno_id = ?');
    valores.push(aluno);
  }
  if (anoLetivo !== null) {
    condicoes.push('ano_letivo = ?');
    valores.push(anoLetivo);
  }
  if (bimestre !== null) {
    condicoes.push('bimestre_numero = ?');
    valores.push(bimestre);
  }
  if (disciplina !== '') {
    condicoes.push('disciplina_nome = ?');
    valores.push(disciplina);
  }

  // Sem nenhum filtro, o WHERE fica vazio e a consulta traz tudo.
  const where = condicoes.length > 0 ? 'WHERE ' + condicoes.join(' AND ') : '';

  try {
    // ---------- 3. Contar o total (para a paginação) ----------
    // O front precisa saber quantas páginas existem para escrever
    // "Página 1 de 3" e desabilitar o botão "Próxima" na última.
    const [contagem] = await pool.query(
      `SELECT COUNT(*) AS total FROM vw_relatorio_publicado ${where}`,
      valores
    );
    const total = contagem[0].total;
    const totalPaginas = Math.max(1, Math.ceil(total / POR_PAGINA));

    // ---------- 4. Buscar só a página pedida ----------
    // LIMIT = quantos trazer; OFFSET = quantos pular.
    // Página 1 pula 0, página 2 pula 10, página 3 pula 20...
    const offset = (pagina - 1) * POR_PAGINA;

    // Minimização de dados (LGPD): a lista NÃO traz a "descricao"
    // (o texto completo do professor). Ela só é necessária na página
    // de detalhe, que buscará um relatório por vez.
    const [linhas] = await pool.query(
      `SELECT acompanhamento_id, aluno_id, aluno_nome, turma_nome,
              disciplina_nome, professor_nome, bimestre_numero,
              ano_letivo, media, publicado_em
         FROM vw_relatorio_publicado
         ${where}
        ORDER BY publicado_em DESC, acompanhamento_id DESC
        LIMIT ? OFFSET ?`,
      [...valores, POR_PAGINA, offset] // "..." copia os valores dos filtros e acrescenta LIMIT e OFFSET
    );

    // ---------- 5. Responder em JSON ----------
    // Formato pensado para o front: os dados da paginação + a lista.
    return res.json({
      pagina,
      porPagina: POR_PAGINA,
      total,
      totalPaginas,
      relatorios: linhas.map((linha) => ({
        id: linha.acompanhamento_id,
        alunoId: linha.aluno_id,
        aluno: linha.aluno_nome,
        turma: linha.turma_nome,
        disciplina: linha.disciplina_nome,
        professor: linha.professor_nome,
        bimestre: linha.bimestre_numero,
        anoLetivo: linha.ano_letivo,
        // DECIMAL chega do mysql2 como texto ("8.50"); Number converte para 8.5.
        media: Number(linha.media),
        publicadoEm: linha.publicado_em,
      })),
    });
  } catch (erro) {
    // O detalhe técnico vai só para o terminal; o usuário recebe uma
    // mensagem genérica (mostrar erro.message poderia expor nomes de
    // tabelas e colunas do banco).
    console.error('Erro em GET /api/relatorios:', erro);
    return res.status(500).json({ erro: 'Não foi possível carregar os relatórios. Tente novamente.' });
  }
});

// ============================================================
// POST /api/login
// Confere e-mail e senha e devolve os dados do usuário (sem a senha).
// Usada por public/js/login.js.
//
// Pedido : { "email": "...", "senha": "..." }
// Sucesso: 200 { "usuario": { "id", "nome", "perfil" } }
// Erros  : 400 (faltou e-mail ou senha)
//          401 (e-mail ou senha não conferem)
//          500 (erro inesperado, ex.: banco fora do ar)
// ============================================================

// Hash "de mentira", comparado quando o e-mail não existe no banco.
// Sem isso, um e-mail inexistente responderia mais rápido que um
// e-mail existente com senha errada, e essa diferença de tempo
// daria pista de quais e-mails estão cadastrados.
const HASH_FALSO = '$2b$10$jMNpXuJcGwKO4zNIAeoZp.egeKeoB/QzNyqrJe0CywY2gfdB2H6xO';

app.post('/api/login', async (req, res) => {
  // req.body pode vir undefined se o pedido não for JSON; o "|| {}"
  // evita erro ao tentar ler email/senha nesse caso.
  const { email, senha } = req.body || {};

  // Validação de novo no servidor: nunca confiar só no front-end.
  if (typeof email !== 'string' || typeof senha !== 'string' ||
      email.trim() === '' || senha === '') {
    return res.status(400).json({ erro: 'Informe e-mail e senha.' });
  }

  try {
    // Busca o usuário pelo e-mail. O "?" é preenchido pelo mysql2 de
    // forma segura (impede SQL Injection). Só usuários ativos entram.
    const [linhas] = await pool.query(
      'SELECT id, nome, senha_hash, perfil FROM usuario WHERE email = ? AND ativo = TRUE',
      [email.trim()]
    );
    const usuario = linhas[0]; // undefined se o e-mail não existe

    // Compara a senha digitada com o hash do banco (ou com o hash
    // falso, se o usuário não existe — ver comentário acima).
    const senhaConfere = await bcrypt.compare(
      senha,
      usuario ? usuario.senha_hash : HASH_FALSO
    );

    // Mesma mensagem para "e-mail não existe" e "senha errada": dizer
    // qual dos dois falhou ajudaria quem tenta adivinhar credenciais.
    if (!usuario || !senhaConfere) {
      return res.status(401).json({ erro: 'E-mail ou senha inválidos.' });
    }

    // Sucesso. Devolve só o necessário (minimização de dados, LGPD):
    // nunca a senha_hash nem o e-mail.
    return res.json({
      usuario: { id: usuario.id, nome: usuario.nome, perfil: usuario.perfil },
    });
  } catch (erro) {
    console.error('Erro em POST /api/login:', erro);
    return res.status(500).json({ erro: 'Não foi possível entrar agora. Tente novamente.' });
  }
});

// ============================================================
// TRATAMENTO DE ROTA INEXISTENTE (404)
// IMPORTANTE: estes dois blocos precisam ficar DEPOIS de todas as
// outras rotas e do express.static. O Express testa as rotas na
// ordem em que foram escritas; se o pedido chegou até aqui, é
// porque nenhuma rota anterior atendeu, ou seja, o endereço não existe.
// Toda rota nova deve ser escrita ACIMA deste bloco.
// ============================================================

// 404 da API: quem chama /api/... é o JavaScript (fetch), que espera
// JSON. Por isso respondemos em JSON, e não com a página HTML.
app.use('/api', (req, res) => {
  res.status(404).json({ erro: 'Rota da API não encontrada.' });
});

// 404 das páginas: qualquer outro endereço inexistente recebe o 404.html.
// res.status(404) é essencial: sem ele, o navegador receberia o código
// 200 ("deu tudo certo") mesmo mostrando uma página de erro.
// path.join monta o caminho completo do arquivo; __dirname é a pasta
// onde este server.js está.
app.use((req, res) => {
  res.status(404).sendFile(path.join(__dirname, 'public', 'html', 'erro404', '404.html'));
});

// ============================================================
// INICIALIZAÇÃO
// ============================================================

// Liga o servidor na porta definida e mostra o endereço no terminal.
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
