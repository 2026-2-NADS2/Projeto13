using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace FecapStudyUI;

// =====================================================================
// MISSÃO 10 — ClienteBackendEstudo
// Conversa com o BackendEstudoAPI.exe (http://localhost:5080) por HTTP/JSON.
// Dependência: recebe Discente/SessaoEstudo/MetaEstudo só como parâmetro.
// =====================================================================
public class ClienteBackendEstudo
{
    private static readonly HttpClient http = new HttpClient
    {
        BaseAddress = new Uri("http://localhost:5080"),
        Timeout = TimeSpan.FromSeconds(5)
    };

    // GET /api/status -> texto curto para a barra de status da tela
    public async Task<string> VerificarStatusAsync()
    {
        try
        {
            string json = await http.GetStringAsync("/api/status");
            using JsonDocument doc = JsonDocument.Parse(json);
            bool mysql = doc.RootElement.GetProperty("usandoMySql").GetBoolean();
            return mysql ? "Backend online (MySQL conectado)" : "Backend online (modo JSON local, sem MySQL)";
        }
        catch (Exception)
        {
            return "Backend OFFLINE — abra o iniciar_backend.bat";
        }
    }

    // POST /api/sessoes -> grava a sessão concluída no banco
    public async Task<bool> SalvarSessaoAsync(Discente discente, SessaoEstudo sessao)
    {
        var dados = new
        {
            discenteNome = discente.GetNome(),
            disciplina = sessao.GetDisciplina().GetNome(),
            tipoModalidade = sessao.ObterModalidade(),
            duracaoMinutos = sessao.GetDuracaoMinutos(),
            xpGanho = sessao.CalcularXp(),
            resumoFeedback = sessao.GerarFeedback()
        };
        return await PostarAsync("/api/sessoes", JsonSerializer.Serialize(dados));
    }

    // POST /api/metas -> cria ou atualiza a meta semanal do discente
    public async Task<bool> SalvarMetaAsync(Discente discente, Responsavel responsavel, MetaEstudo meta)
    {
        var dados = new
        {
            discenteNome = discente.GetNome(),
            responsavelNome = responsavel.GetNome(),
            metaMinutosSemana = meta.GetMetaMinutosSemana()
        };
        return await PostarAsync("/api/metas", JsonSerializer.Serialize(dados));
    }

    // POST /api/usuarios -> usa o ParaJson() do Discente (IExportavelJson)
    public async Task<bool> SalvarDiscenteAsync(Discente discente)
    {
        return await PostarAsync("/api/usuarios", discente.ParaJson());
    }

    // GET /api/relatorio/{nome} -> boletim consolidado, já formatado em linhas
    public async Task<List<string>> BuscarRelatorioAsync(string nomeDiscente)
    {
        List<string> linhas = new List<string>();
        try
        {
            string json = await http.GetStringAsync("/api/relatorio/" + Uri.EscapeDataString(nomeDiscente));
            using JsonDocument doc = JsonDocument.Parse(json);
            JsonElement r = doc.RootElement;

            linhas.Add("=== RELATÓRIO DO SERVIDOR: " + nomeDiscente + " ===");
            linhas.Add("Sessões gravadas: " + r.GetProperty("totalSessoes").GetInt32());
            linhas.Add("Minutos estudados: " + r.GetProperty("totalMinutosEstudados").GetInt32());
            linhas.Add("XP acumulado: " + r.GetProperty("totalXpAcumulado").GetInt32());
            linhas.Add("Meta semanal: " + r.GetProperty("metaMinutosSemana").GetInt32() + " min (" +
                       r.GetProperty("percentualMetaConcluida").GetDouble() + "%)");
            linhas.Add("Status: " + r.GetProperty("statusAcompanhamento").GetString());
            linhas.Add("--- Sessões recentes ---");
            foreach (JsonElement s in r.GetProperty("sessoesRecentes").EnumerateArray())
            {
                linhas.Add($"{s.GetProperty("dataRegistro").GetString()} | " +
                           $"{s.GetProperty("disciplina").GetString()} | " +
                           $"{s.GetProperty("tipoModalidade").GetString()} | " +
                           $"{s.GetProperty("duracaoMinutos").GetInt32()} min | " +
                           $"+{s.GetProperty("xpGanho").GetInt32()} XP");
            }
        }
        catch (Exception ex)
        {
            linhas.Add("Não foi possível falar com o backend: " + ex.Message);
            linhas.Add("Confira se o iniciar_backend.bat está aberto e se http://localhost:5080 abre no navegador.");
        }
        return linhas;
    }

    // Método auxiliar privado: envia um JSON e diz se deu certo
    private async Task<bool> PostarAsync(string rota, string json)
    {
        try
        {
            StringContent conteudo = new StringContent(json, Encoding.UTF8, "application/json");
            HttpResponseMessage resposta = await http.PostAsync(rota, conteudo);
            return resposta.IsSuccessStatusCode;
        }
        catch (Exception)
        {
            return false;
        }
    }
}
