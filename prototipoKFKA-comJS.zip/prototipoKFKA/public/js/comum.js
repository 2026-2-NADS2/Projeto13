/* ============================================================
   KFKA - Funções comuns a todas as páginas (public/js/comum.js)
   Plataforma de Acompanhamento Escolar - Entrega 1 (Dev Web)

   O QUE ESTE ARQUIVO FAZ
   1. Guarda e lê o usuário logado (sessionStorage).
   2. Protege as páginas internas: sem login, volta para o login.
   3. Preenche o nome no cabeçalho (#nome-usuario) e faz o botão
      "Sair" (#botao-sair) funcionar.
   4. Oferece funções prontas que os outros arquivos JS reutilizam
      (buscar dados na API, montar tabelas, formatar data e média).

   COMO USAR
   Em TODA página, dentro do <head>, ANTES dos outros scripts:
     <script src="/js/comum.js" defer></script>
   O atributo "defer" faz o navegador esperar o HTML carregar antes
   de rodar o script, então os elementos (#nome-usuario etc.) já
   existem quando o código precisar deles.

   SEGURANÇA - IMPORTANTE (LGPD)
   - A "proteção" feita aqui é só de USABILIDADE: ela evita que a
     pessoa veja uma tela que não é do perfil dela. Qualquer pessoa
     consegue mexer no sessionStorage pelo navegador, então isto NÃO
     é segurança de verdade.
   - A segurança real (Entrega 2) é do BACKEND: toda rota da API
     precisa conferir quem é o usuário e o que ele pode ver.
   - Todo texto que vem da API entra na página com textContent,
     NUNCA com innerHTML, para impedir ataque XSS.
   ============================================================ */

'use strict';   // modo estrito: o navegador avisa de erros comuns (ex.: variável não declarada)


/* ------------------------------------------------------------
   1. CONSTANTES
   ------------------------------------------------------------ */

// Nome da chave onde o usuário logado fica guardado no navegador.
const CHAVE_USUARIO = 'kfka_usuario';

// Para onde cada perfil vai depois do login (valores iguais ao ENUM
// "perfil" da tabela usuario do banco).
const PAGINA_INICIAL_POR_PERFIL = {
  administrador: '/html/admin/admin_inicio.html',
  professor: '/html/professor/professor_inicio.html',
  responsavel: '/html/responsavel/responsavel_inicio.html',
};

// Qual perfil pode acessar cada pasta de páginas.
const PERFIL_POR_PASTA = {
  '/html/admin/': 'administrador',
  '/html/professor/': 'professor',
  '/html/responsavel/': 'responsavel',
};

const PAGINA_LOGIN = '/html/login/login.html';


/* ------------------------------------------------------------
   2. SESSÃO (usuário logado)
   sessionStorage guarda dados só enquanto a aba estiver aberta.
   Fechou a aba, saiu da sessão. Só guardamos o necessário
   (id, nome, perfil): nunca a senha (minimização de dados).
   ------------------------------------------------------------ */

// Guarda o usuário que o login devolveu. Ex.: { id: 2, nome: 'Carla Lima', perfil: 'professor' }
function salvarUsuario(usuario) {
  sessionStorage.setItem(CHAVE_USUARIO, JSON.stringify(usuario));
}

// Lê o usuário guardado. Devolve null se não houver ninguém logado
// (ou se o conteúdo guardado estiver corrompido).
function obterUsuario() {
  try {
    const texto = sessionStorage.getItem(CHAVE_USUARIO);
    return texto ? JSON.parse(texto) : null;
  } catch (erro) {
    return null;   // JSON inválido: trata como "sem login"
  }
}

// Encerra a sessão e volta para o login (RF01).
function sair() {
  sessionStorage.removeItem(CHAVE_USUARIO);
  window.location.href = PAGINA_LOGIN;
}

// Devolve a página inicial do perfil (usada pelo login e pelo guarda).
function paginaInicialDoPerfil(perfil) {
  return PAGINA_INICIAL_POR_PERFIL[perfil] || PAGINA_LOGIN;
}


/* ------------------------------------------------------------
   3. PROTEÇÃO DAS PÁGINAS INTERNAS
   Descobre pela URL em qual pasta a página está e confere se o
   usuário logado é do perfil certo. Ex.: um professor abrindo
   /html/admin/admin_inicio.html volta para o login.
   ------------------------------------------------------------ */
function exigirLogin() {
  const caminho = window.location.pathname;

  // Procura se a página atual está numa das pastas protegidas.
  // Object.keys() lista as pastas; find() pega a primeira que combina.
  const pasta = Object.keys(PERFIL_POR_PASTA).find((p) => caminho.startsWith(p));

  // Login e 404 não estão em pasta protegida: não há o que conferir.
  if (!pasta) return true;

  const usuario = obterUsuario();

  if (!usuario || usuario.perfil !== PERFIL_POR_PASTA[pasta]) {
    // replace() troca a página no histórico: o botão "Voltar" do
    // navegador não devolve a pessoa para uma tela proibida.
    window.location.replace(PAGINA_LOGIN);
    return false;
  }
  return true;
}


/* ------------------------------------------------------------
   4. CABEÇALHO: nome do usuário e botão Sair
   ------------------------------------------------------------ */
function preencherCabecalho() {
  const usuario = obterUsuario();

  const campoNome = document.getElementById('nome-usuario');
  // textContent (e não innerHTML): o nome é texto, nunca HTML.
  if (campoNome && usuario) campoNome.textContent = usuario.nome;

  const botaoSair = document.getElementById('botao-sair');
  if (botaoSair) botaoSair.addEventListener('click', sair);
}


/* ------------------------------------------------------------
   5. BUSCAR DADOS NA API (fetch)
   Função única para todas as chamadas: assim o tratamento de erro
   fica igual em todo o sistema.
   ------------------------------------------------------------ */

// Faz a requisição e devolve os dados em objeto. Se algo der errado,
// LANÇA um Error com uma mensagem pronta para mostrar ao usuário.
//   url      -> endereço da API (ex.: '/api/relatorios?bimestre=3')
//   opcoes   -> configurações do fetch (method, headers, body...)
async function buscarJSON(url, opcoes) {
  let resposta;

  try {
    resposta = await fetch(url, opcoes);
  } catch (erro) {
    // fetch só "falha" de verdade quando não consegue nem chegar ao
    // servidor (servidor desligado, sem internet).
    throw new Error('Não foi possível conectar ao servidor. Verifique sua conexão e tente novamente.');
  }

  // A API responde JSON, inclusive nos erros: { "erro": "mensagem" }.
  // Se vier algo que não é JSON (ex.: página de erro), dados fica null.
  let dados = null;
  try {
    dados = await resposta.json();
  } catch (erro) {
    dados = null;
  }

  // resposta.ok é true para status 200 a 299.
  if (!resposta.ok) {
    const mensagem = dados && dados.erro
      ? dados.erro
      : 'Ocorreu um erro inesperado. Tente novamente.';
    const erro = new Error(mensagem);
    erro.status = resposta.status;   // guarda o status (400, 401, 500...) caso alguém precise
    throw erro;
  }

  return dados;
}


/* ------------------------------------------------------------
   6. FORMATAÇÃO DE DATA E MÉDIA
   ------------------------------------------------------------ */

// "2026-09-18T18:00:00.000Z" -> "18/09/2026"
function formatarData(dataISO) {
  if (!dataISO) return '-';
  const data = new Date(dataISO);
  if (Number.isNaN(data.getTime())) return '-';   // data inválida
  return data.toLocaleDateString('pt-BR');
}

// 8.5 -> "8,5"    9 -> "9,0"   (vírgula e sempre uma casa decimal)
function formatarMedia(media) {
  if (typeof media !== 'number' || Number.isNaN(media)) return '-';
  return media.toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 });
}


/* ------------------------------------------------------------
   7. MONTAR TABELAS SEM innerHTML
   Criamos cada elemento com document.createElement e colocamos o
   texto com textContent. Assim, mesmo que um nome tenha "<script>",
   o navegador mostra como texto e não executa.
   ------------------------------------------------------------ */

// Cria uma célula <td> só com texto.
function criarCelula(texto) {
  const td = document.createElement('td');
  td.textContent = texto;
  return td;
}

// Cria uma célula <td> com um link dentro (coluna "Ações").
//   textoAcessivel (opcional) vira aria-label: o leitor de tela lê
//   "Ver relatório de Matemática de Ana Souza" em vez de "Ver relatório"
//   repetido em todas as linhas.
function criarCelulaComLink(texto, endereco, textoAcessivel) {
  const td = document.createElement('td');
  const a = document.createElement('a');
  a.textContent = texto;
  a.href = endereco;
  if (textoAcessivel) a.setAttribute('aria-label', textoAcessivel);
  td.appendChild(a);
  return td;
}

// Troca TODO o conteúdo do <tbody> por UMA linha com uma mensagem
// (usada para "Carregando...", "Nenhum resultado" e erros).
//   tbody     -> elemento <tbody>
//   colunas   -> quantas colunas a tabela tem (colspan)
//   texto     -> mensagem
//   ehErro    -> true acrescenta a classe .erro (texto vermelho no CSS)
function mostrarMensagemNaTabela(tbody, colunas, texto, ehErro) {
  const tr = document.createElement('tr');
  const td = document.createElement('td');

  td.colSpan = colunas;
  td.textContent = texto;
  if (ehErro) td.classList.add('erro');

  tr.appendChild(td);
  tbody.replaceChildren(tr);   // remove o que havia e coloca só esta linha
}


/* ------------------------------------------------------------
   8. INICIALIZAÇÃO
   Roda assim que este arquivo carrega (o "defer" garante que o
   HTML já está pronto).
   ------------------------------------------------------------ */
if (exigirLogin()) {
  preencherCabecalho();
}
