# KFKA – Plataforma de Acompanhamento Escolar

Projeto Interdisciplinar · 2º ADS · FECAP · 2026

Sistema web para escolas de Ensino Fundamental. O **Professor** registra o acompanhamento bimestral, a **Coordenação** revisa e publica, e a **Família** consulta o relatório, baixa em PDF e registra ciência.

## Estrutura

```
prototipoKFKA/
├── banco/            schema.sql (tabelas, índices, view) e seed.sql (dados FICTÍCIOS)
├── server/           API: Node.js + Express + MySQL (mysql2) + JWT
│   ├── server.js         ponto de entrada, CORS, tratador de erros
│   ├── db.js             pool de conexões (credenciais no .env)
│   ├── middlewares/      autenticar (token) e exigirPerfil (perfil)
│   ├── modelos/          FluxoAcompanhamento: a classe do fluxo de estados
│   ├── rotas/            conta, geral, responsavel, professor, admin
│   └── utilitarios/      validação e ErroHttp
└── client/           Front-end: React + Vite + React Router (aulas 06 a 08 e 12)
    └── src/
        ├── paginas/          uma pasta por perfil (15 telas + login + 404)
        ├── componentes/      Cabecalho, RotaProtegida, Trilha, Paginacao...
        ├── contextos/        AutenticacaoContexto (usuário logado + token)
        ├── servicos/         todas as chamadas à API (fetch)
        ├── utilitarios/      formatação, validação, hook useBusca
        └── index.css         o style.css da Entrega 1, adaptado
```

Na Entrega 1, o front era HTML + JavaScript puro, na pasta `public/`. Na Entrega 2 ele virou o app React da pasta `client/`, que mantém as mesmas tags, os mesmos `id`s e o mesmo CSS. O servidor agora só responde JSON.

## Como rodar no computador

Pré-requisitos: Node.js 20 ou mais novo e MySQL 8.

**1. Banco de dados** (na pasta `prototipoKFKA`):

```bash
mysql -u root -p < banco/schema.sql
mysql -u root -p kfka < banco/seed.sql
```

**2. API** (terminal 1):

```bash
cd server
cp .env.example .env      # depois abra o .env e preencha a senha do MySQL e o JWT_SECRET
npm install
npm run dev               # http://localhost:3000/api/saude deve responder {"ok":true}
```

**3. Front-end** (terminal 2):

```bash
cd client
npm install
npm run dev               # abra http://localhost:5173
```

### Usuários de teste (senha de todos: `senha123`)

| Perfil | E-mail | O que testar |
|---|---|---|
| Administrador | coordenacao@escola-teste.com | revisar, alterar com justificativa, publicar, períodos, exportar |
| Professor | carla.lima@escola-teste.com | registrar, salvar rascunho, enviar, corrigir o devolvido (Bruno Lima) |
| Professor | rafael.dias@escola-teste.com | só vê as turmas dele |
| Responsável | mariana.souza@exemplo.com | mãe da Ana e do Pedro: relatórios, PDF, ciência |
| Responsável | joao.pereira@exemplo.com | pai do Igor (a Mariana NÃO vê o Igor) |

No seed, o **4º bimestre está aberto de 01/11 a 10/12/2026**, para a Entrega 2 e a apresentação. O administrador pode mudar essas datas na tela **Períodos**.

## Roteiro de demonstração (cenário de ponta a ponta do PI)

1. **Admin** → Períodos: confere que o 4º bimestre está aberto.
2. **Professor (Carla)** → Minhas turmas → 5º A – Matemática → "Registrar" na Ana Souza → preenche e clica em **Enviar para revisão**.
3. **Admin** → Início → "Revisar" → altera a média (exige justificativa) → **Publicar**. O histórico mostra cada passo.
4. **Responsável (Mariana)** → o relatório aparece em "Recentes" → abre → **Baixar em PDF** → **Registrar ciência**.
5. **Professor** → abre o mesmo acompanhamento e vê o retorno da família.
6. **Admin** → Revisão → **Exportar (.csv)** abre no Excel.

## API

Todas as respostas são JSON. Em caso de erro, a resposta é `{ "erro": "mensagem" }`, com o status HTTP certo (400, 401, 403, 404, 409 ou 500). Menos o login, todas as rotas exigem o cabeçalho `Authorization: Bearer <token>`.

| Método e rota | Perfil | Para quê |
|---|---|---|
| `POST /api/login` | público | devolve `{ token, usuario }` |
| `GET /api/conta` · `PUT /api/conta/senha` | todos | dados da conta e troca de senha |
| `GET /api/tags` · `GET /api/bimestres` | professor, admin | dados de apoio |
| `GET /api/responsavel/alunos` | responsável | alunos vinculados |
| `GET /api/responsavel/relatorios` | responsável | lista paginada, só dos alunos vinculados e só publicados |
| `GET /api/responsavel/relatorios/:id` | responsável | detalhe (404 se for de outra família) |
| `POST /api/responsavel/relatorios/:id/ciencia` | responsável | RF12 |
| `GET /api/professor/turmas` | professor | turmas e disciplinas vinculadas |
| `GET /api/professor/turmas/:id/alunos` | professor | alunos e situação no bimestre |
| `GET/POST /api/professor/acompanhamentos` | professor | listar e criar (rascunho ou enviar) |
| `GET/PUT /api/professor/acompanhamentos/:id` | professor | ver e editar (só rascunho/devolvido, no período) |
| `GET /api/admin/resumo` · `GET /api/admin/filtros` | admin | painel e opções dos filtros |
| `GET /api/admin/acompanhamentos` | admin | lista paginada com filtros |
| `GET /api/admin/acompanhamentos/exportar` | admin | CSV para o Excel (RF11) |
| `GET/PUT /api/admin/acompanhamentos/:id` | admin | ver e alterar com justificativa |
| `POST /api/admin/acompanhamentos/:id/decisao` | admin | publicar, devolver ou cancelar |
| `GET /api/admin/acompanhamentos/:id/historico` | admin | auditoria (RF07) |
| `PUT /api/admin/bimestres/:id` | admin | período de digitação (RF04) |

## Segurança e LGPD (o que foi feito e onde)

- **Senhas com hash bcrypt.** A senha nunca é guardada nem devolvida (`rotas/conta.js`).
- **Login com JWT e expiração** (`JWT_EXPIRA`, padrão 2h). O React volta ao login com o aviso "Sua sessão expirou".
- **Autorização em toda rota** (`middlewares/autenticacao.js`): 401 sem login, 403 com o perfil errado.
- **Filtro por vínculo.** O responsável só vê os alunos da tabela `aluno_responsavel` e o professor só vê as próprias turmas (`turma_disc_prof`). Isso corrigiu a falha da Entrega 1, em que a Mariana via o relatório do Igor.
- **SQL Injection:** todos os valores vão como parâmetros `?` do mysql2.
- **XSS:** o JSX sempre mostra textos como texto; não há `dangerouslySetInnerHTML`.
- **CSRF:** o token vai no cabeçalho, e não em cookie, então outro site não consegue usá-lo.
- **Minimização de dados:** as listas não trazem a descrição e a exportação não inclui textos sobre a criança.
- **Auditoria:** a classe `FluxoAcompanhamento` grava o histórico em toda mudança de status, dentro de uma transação.
- **Credenciais fora do código:** ficam no `server/.env`, que está no `.gitignore`.

## Publicar (Entrega 2: "aplicação publicada")

1. **Banco MySQL na nuvem.** O Render não oferece MySQL. Use, por exemplo, Aiven (plano gratuito) ou Railway. Rode `schema.sql` e `seed.sql` nele. No Aiven, use `DB_SSL=true` e cole o "CA certificate" do serviço em `DB_SSL_CA`.
2. **API no Render** (Web Service):
   - Root Directory: `server`
   - Build: `npm install`
   - Start: `npm start`
   - Variáveis: as mesmas do `.env.example`, com `CORS_ORIGIN` igual à URL do Netlify.
3. **Front no Netlify:**
   - Base directory: `client`
   - Build: `npm run build`
   - Publish: `client/dist`
   - Antes do build, ponha a URL do Render em `client/.env.production`.
   - O arquivo `public/_redirects` já resolve o problema do F5.

## O que ainda não está no sistema

- **RF02/RF03:** telas de cadastro (alunos, responsáveis, professores, turmas, vínculos). Hoje esses dados vêm do `seed.sql`.
- **RF01 – recuperação de senha por e-mail.** A tela de login orienta a procurar a secretaria.
- **RF09:** o PDF usa a impressão do navegador ("Salvar como PDF"). Uma biblioteca como jsPDF geraria o arquivo direto.
