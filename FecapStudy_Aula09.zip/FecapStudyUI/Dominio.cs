using System;
using System.Collections.Generic;
using System.Text.Encodings.Web;
using System.Text.Json;

namespace FecapStudyUI;

// =====================================================================
// FecapStudy — Classes de domínio (Missões 1 a 8 da Aula 9)
// Cada bloco abaixo indica a missão e o conceito de POO aplicado.
// =====================================================================


// ---------------------------------------------------------------------
// Utilitário para gerar JSON legível (acentos sem ç etc.)
// ---------------------------------------------------------------------
public static class JsonUtil
{
    public static readonly JsonSerializerOptions Opcoes = new JsonSerializerOptions
    {
        Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
    };

    public static string Serializar(object dados)
    {
        return JsonSerializer.Serialize(dados, Opcoes);
    }
}


// =====================================================================
// MISSÃO 1 — Abstração, Classe e Objeto
// =====================================================================
public class Disciplina
{
    private string codigo;
    private string nome;
    private string categoria;
    private int cargaHorariaSemanalHoras;

    public Disciplina(string codigo, string nome, string categoria, int cargaHorariaSemanalHoras)
    {
        this.codigo = codigo;
        this.nome = nome;
        this.categoria = categoria;
        // Regra: carga <= 0 vira o padrão de 2 horas
        this.cargaHorariaSemanalHoras = cargaHorariaSemanalHoras <= 0 ? 2 : cargaHorariaSemanalHoras;
    }

    public string GetCodigo() { return codigo; }
    public string GetNome() { return nome; }
    public string GetCategoria() { return categoria; }
    public int GetCargaHorariaSemanalHoras() { return cargaHorariaSemanalHoras; }

    public int CalcularCargaEmMinutos()
    {
        return cargaHorariaSemanalHoras * 60;
    }

    public string ExibirResumo()
    {
        return $"[{codigo}] {nome} ({categoria}) — {cargaHorariaSemanalHoras}h/semana ({CalcularCargaEmMinutos()} min)";
    }

    // Usado pelo ComboBox da tela para mostrar o nome da disciplina
    public override string ToString()
    {
        return nome;
    }
}


// =====================================================================
// MISSÃO 6 — Interfaces (declaradas aqui porque as classes abaixo usam)
// =====================================================================

// Contrato: qualquer canal que saiba enviar um alerta
public interface INotificador
{
    string ObterCanal();
    bool EnviarAlerta(string destinatario, string mensagem);
}

// Contrato: qualquer objeto que saiba se converter em JSON para a API
public interface IExportavelJson
{
    string ParaJson();
}


// =====================================================================
// MISSÃO 2 — Encapsulamento (+ IExportavelJson da Missão 6)
// =====================================================================
public class MetaEstudo : IExportavelJson
{
    private int metaMinutosSemana;
    private int minutosCumpridos;   // sempre começa em 0 e NÃO tem set livre

    public MetaEstudo(int metaMinutosSemana)
    {
        minutosCumpridos = 0;
        RedefinirMeta(metaMinutosSemana);   // reaproveita a validação
    }

    public int GetMetaMinutosSemana() { return metaMinutosSemana; }
    public int GetMinutosCumpridos() { return minutosCumpridos; }

    // Única forma de somar minutos: com validação
    public bool RegistrarAvanco(int minutos)
    {
        if (minutos <= 0) return false;     // negativo ou zero: recusa
        if (minutos > 480) return false;    // mais de 8h seguidas: provável erro
        minutosCumpridos += minutos;
        return true;
    }

    // Usado pelo Responsável: trava a meta entre 30 e 3000 minutos
    public void RedefinirMeta(int novaMeta)
    {
        if (novaMeta < 30) novaMeta = 30;
        if (novaMeta > 3000) novaMeta = 3000;
        metaMinutosSemana = novaMeta;
    }

    // De 0 a 100, travado em 100 mesmo se estudar além da meta
    public double CalcularPercentual()
    {
        double p = minutosCumpridos * 100.0 / metaMinutosSemana;
        return p > 100.0 ? 100.0 : p;
    }

    public bool EstaCumprida()
    {
        return minutosCumpridos >= metaMinutosSemana;
    }

    public string ParaJson()
    {
        return JsonUtil.Serializar(new
        {
            metaMinutosSemana = metaMinutosSemana,
            minutosCumpridos = minutosCumpridos
        });
    }
}


// =====================================================================
// MISSÃO 3 — Classe Abstrata e Herança
// =====================================================================
public abstract class Usuario
{
    private int id;
    private string nome;
    private string email;
    private string senha;   // sem getter: dado totalmente privado

    protected Usuario(int id, string nome, string email, string senha)
    {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.senha = senha;
    }

    public int GetId() { return id; }
    public string GetNome() { return nome; }
    public string GetEmail() { return email; }

    // Compara a senha sem nunca expô-la
    public bool Autenticar(string senhaDigitada)
    {
        return senha == senhaDigitada;
    }

    // Métodos abstratos: cada perfil é obrigado a implementar
    public abstract string ObterTipoPerfil();
    public abstract string GerarPainelResumo();
}

public class Administrador : Usuario
{
    private string cargo;

    public Administrador(int id, string nome, string email, string senha, string cargo)
        : base(id, nome, email, senha)
    {
        this.cargo = cargo;
    }

    public string GetCargo() { return cargo; }

    public override string ObterTipoPerfil()
    {
        return "Administrador";
    }

    public override string GerarPainelResumo()
    {
        return $"[Administrador] {GetNome()} — {cargo}";
    }
}

// MISSÃO 7 — Associação: Responsavel ——> Discente
public class Responsavel : Usuario
{
    private string parentesco;
    private List<Discente> discentesAcompanhados = new List<Discente>();
    private Dictionary<string, MetaEstudo> metasPorRa = new Dictionary<string, MetaEstudo>();

    public Responsavel(int id, string nome, string email, string senha, string parentesco)
        : base(id, nome, email, senha)
    {
        this.parentesco = parentesco;
    }

    public string GetParentesco() { return parentesco; }

    // Recebe um Discente criado FORA da classe (associação) e não duplica
    public bool VincularDiscente(Discente d)
    {
        if (discentesAcompanhados.Contains(d))
            return false;
        discentesAcompanhados.Add(d);
        return true;
    }

    public int TotalAcompanhados()
    {
        return discentesAcompanhados.Count;
    }

    // O responsável define (ou redefine) a meta semanal de um discente vinculado
    public MetaEstudo DefinirMeta(Discente d, int minutosSemana)
    {
        VincularDiscente(d);
        if (metasPorRa.ContainsKey(d.GetRa()))
        {
            metasPorRa[d.GetRa()].RedefinirMeta(minutosSemana);
        }
        else
        {
            metasPorRa[d.GetRa()] = new MetaEstudo(minutosSemana);
        }
        return metasPorRa[d.GetRa()];
    }

    public MetaEstudo? ObterMeta(Discente d)
    {
        return metasPorRa.ContainsKey(d.GetRa()) ? metasPorRa[d.GetRa()] : null;
    }

    public override string ObterTipoPerfil()
    {
        return "Responsavel";
    }

    public override string GerarPainelResumo()
    {
        return $"[Responsável] {GetNome()} ({parentesco}) — acompanha {discentesAcompanhados.Count} discente(s)";
    }
}

public class Discente : Usuario, IExportavelJson
{
    private string ra;
    private int xpTotal;
    // MISSÃO 5 — histórico privado das sessões
    private List<SessaoEstudo> historico = new List<SessaoEstudo>();

    public Discente(int id, string nome, string email, string senha, string ra)
        : base(id, nome, email, senha)
    {
        this.ra = ra;
        xpTotal = 0;
    }

    public string GetRa() { return ra; }
    public int GetXpTotal() { return xpTotal; }

    // Devolve uma CÓPIA para ninguém mexer no histórico por fora
    public List<SessaoEstudo> GetHistorico()
    {
        return new List<SessaoEstudo>(historico);
    }

    public void AdicionarXp(int pontos)
    {
        if (pontos > 0)
            xpTotal += pontos;
    }

    // ---------- MISSÃO 5 — Polimorfismo Estático (sobrecarga) ----------

    // Forma 1: recebe a sessão pronta
    public void RegistrarEstudo(SessaoEstudo sessao)
    {
        historico.Add(sessao);
        AdicionarXp(sessao.CalcularXp());
    }

    // Forma 2 (atalho rápido): cria um Pomodoro padrão
    public SessaoEstudo RegistrarEstudo(Disciplina d, int minutos)
    {
        int ciclos = minutos / 25;
        if (ciclos < 1) ciclos = 1;
        SessaoEstudo sessao = new SessaoPomodoro(d, minutos, ciclos);
        RegistrarEstudo(sessao);
        return sessao;
    }

    // Forma 3 (por horário): cria uma Leitura com resumo
    public SessaoEstudo RegistrarEstudo(Disciplina d, int horaInicio, int horaFim, int paginasLidas)
    {
        int minutos = (horaFim - horaInicio) * 60;
        SessaoEstudo sessao = new SessaoLeitura(d, minutos, paginasLidas, true);
        RegistrarEstudo(sessao);
        return sessao;
    }

    public override string ObterTipoPerfil()
    {
        return "Discente";
    }

    public override string GerarPainelResumo()
    {
        return $"[Discente] {GetNome()} — RA {ra} | XP: {xpTotal} | Sessões: {historico.Count}";
    }

    // JSON no formato do POST /api/usuarios
    public string ParaJson()
    {
        return JsonUtil.Serializar(new
        {
            nome = GetNome(),
            email = GetEmail(),
            tipoPerfil = ObterTipoPerfil(),
            matriculaOuCargo = ra
        });
    }
}


// =====================================================================
// MISSÃO 4 — Polimorfismo Dinâmico (+ IExportavelJson da Missão 6)
// =====================================================================
public abstract class SessaoEstudo : IExportavelJson
{
    private Disciplina disciplina;
    private int duracaoMinutos;

    protected SessaoEstudo(Disciplina disciplina, int duracaoMinutos)
    {
        this.disciplina = disciplina;
        this.duracaoMinutos = duracaoMinutos < 0 ? 0 : duracaoMinutos;
    }

    public Disciplina GetDisciplina() { return disciplina; }
    public int GetDuracaoMinutos() { return duracaoMinutos; }

    public abstract string ObterModalidade();
    public abstract int CalcularXp();

    public virtual string GerarFeedback()
    {
        return $"{ObterModalidade()} em {disciplina.GetNome()} ({duracaoMinutos} min) -> +{CalcularXp()} XP";
    }

    // JSON com os mesmos nomes de campo que o backend espera em /api/sessoes
    public string ParaJson()
    {
        return JsonUtil.Serializar(new
        {
            disciplina = disciplina.GetNome(),
            tipoModalidade = ObterModalidade(),
            duracaoMinutos = duracaoMinutos,
            xpGanho = CalcularXp(),
            resumoFeedback = GerarFeedback()
        });
    }
}

public class SessaoPomodoro : SessaoEstudo
{
    private int ciclosCompletos;

    public SessaoPomodoro(Disciplina disciplina, int duracaoMinutos, int ciclosCompletos)
        : base(disciplina, duracaoMinutos)
    {
        this.ciclosCompletos = ciclosCompletos < 0 ? 0 : ciclosCompletos;
    }

    public int GetCiclosCompletos() { return ciclosCompletos; }

    public override string ObterModalidade()
    {
        return "Pomodoro";
    }

    public override int CalcularXp()
    {
        return GetDuracaoMinutos() * 2 + ciclosCompletos * 15;
    }

    public override string GerarFeedback()
    {
        return base.GerarFeedback() + $" | {ciclosCompletos} ciclo(s) concluído(s)";
    }
}

public class SessaoExercicios : SessaoEstudo
{
    private int totalQuestoes;
    private int acertos;

    public SessaoExercicios(Disciplina disciplina, int duracaoMinutos, int totalQuestoes, int acertos)
        : base(disciplina, duracaoMinutos)
    {
        this.totalQuestoes = totalQuestoes < 0 ? 0 : totalQuestoes;
        // não deixa ter mais acertos que questões
        if (acertos < 0) acertos = 0;
        if (acertos > this.totalQuestoes) acertos = this.totalQuestoes;
        this.acertos = acertos;
    }

    public int GetTotalQuestoes() { return totalQuestoes; }
    public int GetAcertos() { return acertos; }

    public double PercentualAcerto()
    {
        return totalQuestoes == 0 ? 0 : acertos * 100.0 / totalQuestoes;
    }

    public override string ObterModalidade()
    {
        return "Exercicios";
    }

    public override int CalcularXp()
    {
        return GetDuracaoMinutos() + acertos * 10;
    }

    public override string GerarFeedback()
    {
        return base.GerarFeedback() + $" | {acertos}/{totalQuestoes} acertos ({PercentualAcerto():F0}%)";
    }
}

public class SessaoLeitura : SessaoEstudo
{
    private int paginasLidas;
    private bool fezResumo;

    public SessaoLeitura(Disciplina disciplina, int duracaoMinutos, int paginasLidas, bool fezResumo)
        : base(disciplina, duracaoMinutos)
    {
        this.paginasLidas = paginasLidas < 0 ? 0 : paginasLidas;
        this.fezResumo = fezResumo;
    }

    public int GetPaginasLidas() { return paginasLidas; }
    public bool GetFezResumo() { return fezResumo; }

    public override string ObterModalidade()
    {
        return "Leitura";
    }

    public override int CalcularXp()
    {
        return GetDuracaoMinutos() + paginasLidas * 3 + (fezResumo ? 25 : 0);
    }

    public override string GerarFeedback()
    {
        return base.GerarFeedback() + $" | {paginasLidas} pág." + (fezResumo ? " + resumo" : "");
    }
}


// =====================================================================
// MISSÃO 6 — Classes que assinam o contrato INotificador
// =====================================================================
public class NotificadorEmail : INotificador
{
    private List<string> enviados = new List<string>();

    public string ObterCanal() { return "E-mail"; }

    public bool EnviarAlerta(string destinatario, string mensagem)
    {
        if (!destinatario.Contains("@")) return false;   // e-mail inválido
        enviados.Add($"Para {destinatario}: {mensagem}");
        return true;
    }

    public int TotalEnviados() { return enviados.Count; }
}

public class NotificadorWhatsApp : INotificador
{
    private List<string> enviados = new List<string>();

    public string ObterCanal() { return "WhatsApp"; }

    public bool EnviarAlerta(string destinatario, string mensagem)
    {
        if (string.IsNullOrWhiteSpace(destinatario)) return false;
        enviados.Add($"[Zap] {destinatario}: {mensagem}");
        return true;
    }

    public int TotalEnviados() { return enviados.Count; }
}

public class NotificadorPainel : INotificador
{
    private List<string> avisos = new List<string>();

    public string ObterCanal() { return "Painel"; }

    public bool EnviarAlerta(string destinatario, string mensagem)
    {
        avisos.Add($"{DateTime.Now:HH:mm} — {mensagem}");
        return true;
    }

    public int TotalEnviados() { return avisos.Count; }
}


// =====================================================================
// MISSÃO 7 — Agregação: TrilhaEstudo ◇── Disciplina
// (as disciplinas são criadas FORA e continuam existindo sem a trilha)
// =====================================================================
public class TrilhaEstudo
{
    private string titulo;
    private Administrador administrador;   // associação com quem montou a trilha
    private List<Disciplina> disciplinas = new List<Disciplina>();

    public TrilhaEstudo(string titulo, Administrador administrador)
    {
        this.titulo = titulo;
        this.administrador = administrador;
    }

    public string GetTitulo() { return titulo; }
    public Administrador GetAdministrador() { return administrador; }

    public bool AdicionarDisciplina(Disciplina d)
    {
        if (disciplinas.Contains(d)) return false;
        disciplinas.Add(d);
        return true;
    }

    public int CalcularCargaHorariaTotal()
    {
        int total = 0;
        foreach (Disciplina d in disciplinas)
            total += d.GetCargaHorariaSemanalHoras();
        return total;
    }

    public string ExibirResumo()
    {
        return $"{titulo} (por {administrador.GetNome()}) — {disciplinas.Count} disciplinas, {CalcularCargaHorariaTotal()}h/semana";
    }
}


// =====================================================================
// MISSÃO 8 — Composição: PlanoEstudo ◆── ItemCronograma
// (o item nasce DENTRO do plano e a lista nunca sai da classe)
// =====================================================================
public class ItemCronograma
{
    private string diaSemana;
    private int minutosPlanejados;

    public ItemCronograma(string diaSemana, int minutosPlanejados)
    {
        this.diaSemana = diaSemana;
        this.minutosPlanejados = minutosPlanejados < 0 ? 0 : minutosPlanejados;
    }

    public string GetDiaSemana() { return diaSemana; }
    public int GetMinutosPlanejados() { return minutosPlanejados; }

    public string ExibirResumo()
    {
        return $"{diaSemana}: {minutosPlanejados} min";
    }
}

public class PlanoEstudo
{
    private string titulo;
    private List<ItemCronograma> itens = new List<ItemCronograma>();

    public PlanoEstudo(string titulo)
    {
        this.titulo = titulo;
    }

    public string GetTitulo() { return titulo; }

    // Recebe dados primitivos e cria o item aqui dentro (composição)
    public void AdicionarItem(string diaSemana, int minutos)
    {
        itens.Add(new ItemCronograma(diaSemana, minutos));
    }

    public int CalcularTotalPlanejado()
    {
        int total = 0;
        foreach (ItemCronograma item in itens)
            total += item.GetMinutosPlanejados();
        return total;
    }

    // Devolve só textos, nunca a referência da lista
    public List<string> ListarItens()
    {
        List<string> linhas = new List<string>();
        foreach (ItemCronograma item in itens)
            linhas.Add(item.ExibirResumo());
        return linhas;
    }
}


// =====================================================================
// MISSÃO 8 — Dependência: ServicoAlertaResponsavel - - -> Discente,
// MetaEstudo, Responsavel e INotificador (só usa dentro do método,
// sem guardar em atributos)
// =====================================================================
public class ServicoAlertaResponsavel
{
    // Devolve a mensagem enviada (ou o motivo da falha) para a tela mostrar
    public string AvaliarDiscente(Discente d, MetaEstudo meta, Responsavel resp, INotificador notificador)
    {
        double percentual = meta.CalcularPercentual();
        string mensagem;
        if (meta.EstaCumprida())
            mensagem = $"Parabéns! {d.GetNome()} cumpriu 100% da meta semanal ({meta.GetMetaMinutosSemana()} min).";
        else
            mensagem = $"{d.GetNome()} está com {percentual:F1}% da meta semanal ({meta.GetMinutosCumpridos()}/{meta.GetMetaMinutosSemana()} min).";

        bool enviado = notificador.EnviarAlerta(resp.GetEmail(), mensagem);
        return enviado
            ? $"Enviado por {notificador.ObterCanal()} para {resp.GetEmail()}:\n{mensagem}"
            : $"Falha ao enviar por {notificador.ObterCanal()}.";
    }
}
