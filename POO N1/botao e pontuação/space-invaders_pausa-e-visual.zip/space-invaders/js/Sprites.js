// Sprites: desenhos em pixel art no estilo do Space Invaders original.
// Cada desenho é uma lista de linhas de texto: '#' = pixel pintado, '.' = vazio.
// Os inimigos têm 2 quadros (A e B) para criar o efeito de "andar" do original.
const Sprites = {
  // Lula (linhas de cima, 30 pontos) -> usada pelo InimigoAtirador
  LULA: [
    [
      '...##...',
      '..####..',
      '.######.',
      '##.##.##',
      '########',
      '..#..#..',
      '.#.##.#.',
      '#.#..#.#',
    ],
    [
      '...##...',
      '..####..',
      '.######.',
      '##.##.##',
      '########',
      '.#.##.#.',
      '#......#',
      '.#....#.',
    ],
  ],

  // Caranguejo (linhas do meio, 20 pontos) -> usado pelo InimigoRapido
  CARANGUEJO: [
    [
      '..#.....#..',
      '...#...#...',
      '..#######..',
      '.##.###.##.',
      '###########',
      '#.#######.#',
      '#.#.....#.#',
      '...##.##...',
    ],
    [
      '..#.....#..',
      '#..#...#..#',
      '#.#######.#',
      '###.###.###',
      '###########',
      '.#########.',
      '..#.....#..',
      '.#.......#.',
    ],
  ],

  // Polvo (linhas de baixo, 10 pontos) -> usado pelo InimigoBasico
  POLVO: [
    [
      '....####....',
      '.##########.',
      '############',
      '###..##..###',
      '############',
      '...##..##...',
      '..##.##.##..',
      '##........##',
    ],
    [
      '....####....',
      '.##########.',
      '############',
      '###..##..###',
      '############',
      '..###..###..',
      '.##..##..##.',
      '..##....##..',
    ],
  ],

  // Canhão do jogador (só 1 quadro)
  CANHAO: [
    [
      '......#......',
      '.....###.....',
      '.....###.....',
      '.###########.',
      '#############',
      '#############',
      '#############',
    ],
  ],

  // Desenha um sprite esticado para caber exatamente na caixa (x, y, largura, altura)
  // da entidade. Os valores são arredondados para não aparecerem frestas entre os pixels.
  desenhar(ctx, mapa, x, y, largura, altura, cor) {
    const colunas = mapa[0].length;
    const linhas = mapa.length;
    ctx.fillStyle = cor;

    for (let l = 0; l < linhas; l++) {
      for (let c = 0; c < colunas; c++) {
        if (mapa[l][c] !== '#') continue;
        const x0 = Math.round(x + (c * largura) / colunas);
        const x1 = Math.round(x + ((c + 1) * largura) / colunas);
        const y0 = Math.round(y + (l * altura) / linhas);
        const y1 = Math.round(y + ((l + 1) * altura) / linhas);
        ctx.fillRect(x0, y0, x1 - x0, y1 - y0);
      }
    }
  },
};
