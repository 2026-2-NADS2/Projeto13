# FecapStudy — Aula 9 (Missões 1 a 10) em C# + Windows Forms

## Arquivos

| Arquivo | O que tem |
|---|---|
| `Dominio.cs` | Missões 1 a 8: Disciplina, MetaEstudo, Usuario (abstrata) + Administrador/Responsavel/Discente, SessaoEstudo (abstrata) + Pomodoro/Exercicios/Leitura, INotificador, IExportavelJson, TrilhaEstudo, PlanoEstudo/ItemCronograma, ServicoAlertaResponsavel |
| `TesteMissoes.cs` | Testes de mesa das Missões 1 a 8 (botão "Rodar testes" na tela) |
| `ClienteBackendEstudo.cs` | Missão 10: HttpClient conversando com http://localhost:5080 |
| `Program.cs` | Missão 9: a tela (montada por código, sem Designer) |

## Como rodar no laboratório

1. Abra a pasta `Backend` e dê duplo-clique em `iniciar_backend.bat`. Deixe a janela preta aberta.
2. Em outro terminal, crie o projeto WinForms:
   ```
   dotnet new winforms -n FecapStudyUI
   cd FecapStudyUI
   ```
3. **Apague** `Form1.cs` e `Form1.Designer.cs` e **substitua** o `Program.cs` pelos 4 arquivos `.cs` desta pasta.
4. Rode:
   ```
   dotnet run
   ```

Se o `dotnet build` reclamar do OneDrive, crie o projeto em `C:\Users\seu_usuario\ProjetosPOO\`.

## Como testar

- **Registrar Estudo**: cria a sessão certa (Pomodoro, Exercicios ou Leitura), soma XP no discente, avança a meta e envia `POST /api/sessoes`. A janela do backend mostra uma linha verde.
- **Notificar Responsável**: usa o canal escolhido (E-mail, WhatsApp ou Painel) pelo `ServicoAlertaResponsavel`.
- **Carregar Histórico do Servidor / Relatório**: faz `GET /api/relatorio/Lucas Silva` e mostra o que está gravado no banco.
- **Rodar testes das Missões 1 a 8**: mostra o resultado de cada missão (os checklists da aula).

Para conferir no navegador: http://localhost:5080/api/sessoes
