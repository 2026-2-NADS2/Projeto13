// Classe Tela: cuida de tudo que aparece POR CIMA do canvas
// (tela de início e tela de fim de jogo).
// Separar isso do Jogo.js segue o princípio de responsabilidade única:
// o Jogo cuida das regras, a Tela cuida só de mostrar/esconder mensagens.
class Tela {
  // aoClicar: função que o Jogo passa para ser chamada quando o botão for clicado.
  constructor(aoClicar) {
    this.overlay = document.getElementById('overlay');
    this.titulo = document.getElementById('overlay-titulo');
    this.texto = document.getElementById('overlay-texto');
    this.placar = document.getElementById('overlay-placar');
    this.botao = document.getElementById('overlay-botao');

    this.botao.addEventListener('click', aoClicar);
  }

  // Tela mostrada ao abrir a página: o jogo só começa quando o jogador decidir.
  mostrarInicio() {
    this.overlay.classList.remove('vitoria', 'derrota');
    this.titulo.textContent = 'SPACE INVADERS LATERAL';
    this.texto.innerHTML =
      'Use as setas (ou W A S D) para mover nos 4 sentidos e a barra de espaço para atirar.<br>' +
      'Destrua os invasores antes que passem pela sua defesa.<br><br>' +
      '<span class="inimigo basico">■</span> Básico: 10 pontos<br>' +
      '<span class="inimigo rapido">■</span> Rápido: 20 pontos<br>' +
      '<span class="inimigo atirador">■</span> Atirador: 30 pontos';
    this.placar.textContent = '';
    this.botao.textContent = 'Iniciar jogo (Enter)';
    this._mostrar();
  }

  // Tela mostrada quando o jogador vence ou perde.
  // venceu: true/false | motivo: texto explicando o fim | pontos: pontuação final
  mostrarFim(venceu, motivo, pontos) {
    this.overlay.classList.remove('vitoria', 'derrota');
    this.overlay.classList.add(venceu ? 'vitoria' : 'derrota');
    this.titulo.textContent = venceu ? 'VOCÊ VENCEU!' : 'GAME OVER';
    this.texto.textContent = motivo;
    this.placar.textContent = `Pontuação final: ${pontos}`;
    this.botao.textContent = 'Jogar novamente (Enter)';
    this._mostrar();
  }

  // Tela mostrada enquanto o jogo está pausado.
  // O botão desta tela continua o jogo (o Jogo decide o que fazer no clique).
  mostrarPausa() {
    this.overlay.classList.remove('vitoria', 'derrota');
    this.titulo.textContent = 'PAUSADO';
    this.texto.textContent = 'Pressione P ou clique em Continuar.';
    this.placar.textContent = '';
    this.botao.textContent = 'Continuar (P)';
    this._mostrar();
  }

  esconder() {
    this.overlay.classList.add('escondido');
    this.botao.blur(); // tira o foco do botão para não reagir à barra de espaço durante o jogo
  }

  // Método interno (começa com _ por convenção): só a própria classe usa.
  _mostrar() {
    this.overlay.classList.remove('escondido');
  }
}
