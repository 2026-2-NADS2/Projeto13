const express = require('express');
const pool = require('./db');

const app = express();
const PORT = 3000;

app.use(express.static('public'));

app.get('/teste-db', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT COUNT(*) AS total FROM usuario');
    res.json({ conectado: true, total_usuarios: rows[0].total });
  } catch (erro) {
    res.status(500).json({ conectado: false, erro: erro.message });
  }
});

app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});