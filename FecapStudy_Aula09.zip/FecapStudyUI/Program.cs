using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace FecapStudyUI;

// =====================================================================
// Ponto de entrada do aplicativo Windows Forms
// =====================================================================
internal static class Program
{
    [STAThread]
    static void Main()
    {
        Application.SetHighDpiMode(HighDpiMode.SystemAware);
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new FormPrincipal());
    }
}

// =====================================================================
// MISSÕES 9 e 10 — Tela da plataforma FecapStudy
// A tela só lê os controles e chama os objetos de domínio:
// nenhuma fórmula de XP ou de meta fica dentro dos eventos de clique.
// =====================================================================
public class FormPrincipal : Form
{
    // ---------- Objetos de domínio (Missões 1 a 8) ----------
    private readonly List<Disciplina> disciplinas;
    private readonly Administrador administrador;
    private readonly Responsavel responsavel;
    private readonly Discente discente;
    private readonly MetaEstudo meta;
    private readonly TrilhaEstudo trilha;
    private readonly PlanoEstudo plano;
    private readonly List<INotificador> notificadores;
    private readonly ServicoAlertaResponsavel servicoAlerta = new ServicoAlertaResponsavel();

    // ---------- Conexão com o backend (Missão 10) ----------
    private readonly ClienteBackendEstudo backend = new ClienteBackendEstudo();

    // ---------- Controles da tela ----------
    private readonly Label lblPainelDiscente = new Label();
    private readonly Label lblPainelResponsavel = new Label();
    private readonly Label lblTrilha = new Label();

    private readonly ComboBox cmbDisciplina = new ComboBox();
    private readonly ComboBox cmbModalidade = new ComboBox();
    private readonly NumericUpDown numDuracao = new NumericUpDown();
    private readonly Label lblExtra = new Label();
    private readonly NumericUpDown numExtra = new NumericUpDown();
    private readonly Label lblTotalQuestoes = new Label();
    private readonly NumericUpDown numTotalQuestoes = new NumericUpDown();
    private readonly CheckBox chkResumo = new CheckBox();
    private readonly Button btnRegistrar = new Button();

    private readonly Label lblMeta = new Label();
    private readonly ProgressBar progressMeta = new ProgressBar();
    private readonly ComboBox cmbCanal = new ComboBox();
    private readonly Button btnNotificar = new Button();
    private readonly Button btnRodarTestes = new Button();

    private readonly ListBox lstHistorico = new ListBox();
    private readonly Button btnCarregarServidor = new Button();
    private readonly TextBox txtServidor = new TextBox();

    private readonly StatusStrip barraStatus = new StatusStrip();
    private readonly ToolStripStatusLabel lblStatus = new ToolStripStatusLabel();

    public FormPrincipal()
    {
        // ---------- Cria os objetos do sistema ----------
        disciplinas = new List<Disciplina>
        {
            new Disciplina("ADS201", "Programação Orientada a Objetos", "Computação", 4),
            new Disciplina("ADS202", "Banco de Dados e Modelagem SQL", "Dados", 3),
            new Disciplina("ADS203", "Projeto Interdisciplinar (PI)", "Projetos", 2),
            new Disciplina("ADS204", "Design de Interface Digital", "Design", 2)
        };

        administrador = new Administrador(1, "Profa. Helena", "helena@fecap.br", "adm123", "Coordenação PI");
        responsavel = new Responsavel(2, "Carlos Silva", "carlos@email.com", "pai123", "Pai");
        discente = new Discente(3, "Lucas Silva", "lucas@fecap.br", "luc123", "RA-101");

        // Associação: o responsável acompanha o discente e define a meta
        responsavel.VincularDiscente(discente);
        meta = responsavel.DefinirMeta(discente, 200);

        // Agregação: a trilha recebe disciplinas que já existem
        trilha = new TrilhaEstudo("Trilha 2º Semestre ADS", administrador);
        foreach (Disciplina d in disciplinas)
            trilha.AdicionarDisciplina(d);

        // Composição: os itens do cronograma nascem dentro do plano
        plano = new PlanoEstudo("Plano semanal do Lucas");
        plano.AdicionarItem("Segunda", 60);
        plano.AdicionarItem("Quarta", 60);
        plano.AdicionarItem("Sábado", 80);

        // Interface: os três canais cumprem o mesmo contrato
        notificadores = new List<INotificador>
        {
            new NotificadorEmail(), new NotificadorWhatsApp(), new NotificadorPainel()
        };

        MontarTela();
        AtualizarTela();
        Shown += async (s, e) => lblStatus.Text = await backend.VerificarStatusAsync();
    }

    // =================================================================
    // Monta os controles por código (não precisa do Designer)
    // =================================================================
    private void MontarTela()
    {
        SuspendLayout();
        Text = "FecapStudy — Plataforma de Apoio ao Estudo";
        Font = new Font("Segoe UI", 9.75F);
        AutoScaleDimensions = new SizeF(96F, 96F);
        AutoScaleMode = AutoScaleMode.Dpi;
        ClientSize = new Size(1000, 690);
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Color.FromArgb(244, 248, 246);

        // ----- Cabeçalho de perfis -----
        GroupBox grpPerfis = Grupo("Perfis (GerarPainelResumo polimórfico)", 12, 10, 976, 110);
        Posicionar(lblPainelDiscente, 15, 25, 940, 22);
        lblPainelDiscente.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
        lblPainelDiscente.ForeColor = Color.FromArgb(0, 110, 70);
        Posicionar(lblPainelResponsavel, 15, 52, 940, 22);
        Posicionar(lblTrilha, 15, 78, 940, 22);
        lblTrilha.ForeColor = Color.DimGray;
        grpPerfis.Controls.AddRange(new Control[] { lblPainelDiscente, lblPainelResponsavel, lblTrilha });

        // ----- Formulário de nova sessão -----
        GroupBox grpSessao = Grupo("Nova Sessão de Estudo", 12, 130, 476, 265);

        cmbDisciplina.DropDownStyle = ComboBoxStyle.DropDownList;
        foreach (Disciplina d in disciplinas)
            cmbDisciplina.Items.Add(d);          // mostra d.ToString() = nome
        cmbDisciplina.SelectedIndex = 0;
        Posicionar(cmbDisciplina, 130, 27, 325, 28);

        cmbModalidade.DropDownStyle = ComboBoxStyle.DropDownList;
        cmbModalidade.Items.AddRange(new object[] { "Pomodoro", "Exercicios", "Leitura" });
        cmbModalidade.SelectedIndexChanged += (s, e) => AjustarCamposDaModalidade();
        Posicionar(cmbModalidade, 130, 62, 325, 28);

        numDuracao.Minimum = 1;
        numDuracao.Maximum = 480;
        numDuracao.Value = 25;
        Posicionar(numDuracao, 130, 97, 100, 28);

        numExtra.Minimum = 0;
        numExtra.Maximum = 500;
        numExtra.Value = 1;
        Posicionar(lblExtra, 15, 135, 110, 22);
        Posicionar(numExtra, 130, 132, 100, 28);

        Posicionar(lblTotalQuestoes, 245, 135, 80, 22);
        lblTotalQuestoes.Text = "Questões:";
        numTotalQuestoes.Minimum = 1;
        numTotalQuestoes.Maximum = 500;
        numTotalQuestoes.Value = 10;
        Posicionar(numTotalQuestoes, 330, 132, 100, 28);

        chkResumo.Text = "Fez resumo do capítulo";
        Posicionar(chkResumo, 130, 167, 250, 26);

        btnRegistrar.Text = "Registrar Estudo";
        EstilizarBotao(btnRegistrar, Color.FromArgb(0, 150, 95));
        Posicionar(btnRegistrar, 15, 208, 440, 42);
        btnRegistrar.Click += BtnRegistrar_Click;

        grpSessao.Controls.AddRange(new Control[]
        {
            Rotulo("Disciplina:", 15, 30), cmbDisciplina,
            Rotulo("Modalidade:", 15, 65), cmbModalidade,
            Rotulo("Duração (min):", 15, 100), numDuracao,
            lblExtra, numExtra, lblTotalQuestoes, numTotalQuestoes,
            chkResumo, btnRegistrar
        });

        // ----- Meta, notificação e testes -----
        GroupBox grpMeta = Grupo("Meta Semanal e Alertas", 500, 130, 488, 265);
        Posicionar(lblMeta, 15, 28, 455, 22);
        progressMeta.Minimum = 0;
        progressMeta.Maximum = 100;
        Posicionar(progressMeta, 15, 55, 455, 28);

        cmbCanal.DropDownStyle = ComboBoxStyle.DropDownList;
        foreach (INotificador n in notificadores)
            cmbCanal.Items.Add(n.ObterCanal());
        cmbCanal.SelectedIndex = 0;
        Posicionar(cmbCanal, 75, 100, 200, 28);

        btnNotificar.Text = "Notificar Responsável";
        EstilizarBotao(btnNotificar, Color.FromArgb(40, 90, 160));
        Posicionar(btnNotificar, 15, 145, 455, 42);
        btnNotificar.Click += BtnNotificar_Click;

        btnRodarTestes.Text = "Rodar testes das Missões 1 a 8";
        EstilizarBotao(btnRodarTestes, Color.FromArgb(110, 110, 110));
        Posicionar(btnRodarTestes, 15, 200, 455, 42);
        btnRodarTestes.Click += BtnRodarTestes_Click;

        grpMeta.Controls.AddRange(new Control[]
        {
            lblMeta, progressMeta, Rotulo("Canal:", 15, 103), cmbCanal, btnNotificar, btnRodarTestes
        });

        // ----- Histórico local -----
        GroupBox grpHistorico = Grupo("Histórico desta sessão (GerarFeedback)", 12, 405, 476, 250);
        lstHistorico.HorizontalScrollbar = true;
        Posicionar(lstHistorico, 12, 25, 450, 212);
        grpHistorico.Controls.Add(lstHistorico);

        // ----- Dados do servidor -----
        GroupBox grpServidor = Grupo("Backend C# + MySQL (http://localhost:5080)", 500, 405, 488, 250);
        btnCarregarServidor.Text = "Carregar Histórico do Servidor / Relatório";
        EstilizarBotao(btnCarregarServidor, Color.FromArgb(0, 120, 120));
        Posicionar(btnCarregarServidor, 12, 25, 462, 36);
        btnCarregarServidor.Click += BtnCarregarServidor_Click;

        txtServidor.Multiline = true;
        txtServidor.ReadOnly = true;
        txtServidor.ScrollBars = ScrollBars.Both;
        txtServidor.WordWrap = false;
        txtServidor.Font = new Font("Consolas", 9F);
        Posicionar(txtServidor, 12, 68, 462, 170);
        grpServidor.Controls.AddRange(new Control[] { btnCarregarServidor, txtServidor });

        // ----- Barra de status -----
        lblStatus.Text = "Verificando backend...";
        barraStatus.Items.Add(lblStatus);

        Controls.AddRange(new Control[] { grpPerfis, grpSessao, grpMeta, grpHistorico, grpServidor, barraStatus });

        cmbModalidade.SelectedIndex = 0;   // dispara AjustarCamposDaModalidade
        ResumeLayout(false);
        PerformLayout();
    }

    // Mostra só os campos que fazem sentido para cada modalidade
    private void AjustarCamposDaModalidade()
    {
        string modalidade = cmbModalidade.SelectedItem?.ToString() ?? "Pomodoro";
        lblTotalQuestoes.Visible = modalidade == "Exercicios";
        numTotalQuestoes.Visible = modalidade == "Exercicios";
        chkResumo.Visible = modalidade == "Leitura";

        if (modalidade == "Pomodoro") lblExtra.Text = "Ciclos:";
        else if (modalidade == "Exercicios") lblExtra.Text = "Acertos:";
        else lblExtra.Text = "Páginas lidas:";
    }

    // Atualiza cabeçalho e barra de progresso com o estado dos objetos
    private void AtualizarTela()
    {
        lblPainelDiscente.Text = discente.GerarPainelResumo();
        lblPainelResponsavel.Text = responsavel.GerarPainelResumo();
        lblTrilha.Text = trilha.ExibirResumo() + "  |  " + plano.GetTitulo() + ": " +
                         string.Join(", ", plano.ListarItens()) + $" ({plano.CalcularTotalPlanejado()} min)";

        double percentual = meta.CalcularPercentual();
        progressMeta.Value = (int)percentual;
        lblMeta.Text = $"{meta.GetMinutosCumpridos()} de {meta.GetMetaMinutosSemana()} min ({percentual:F1}%)" +
                       (meta.EstaCumprida() ? "  —  META CUMPRIDA!" : "");
    }

    // =================================================================
    // Eventos dos botões
    // =================================================================

    // Missão 9 + 10: cria a subclasse certa, registra nos objetos e envia ao backend
    private async void BtnRegistrar_Click(object? sender, EventArgs e)
    {
        if (cmbDisciplina.SelectedItem is not Disciplina disciplina)
            return;

        int minutos = (int)numDuracao.Value;
        int extra = (int)numExtra.Value;

        // Só escolhe QUAL objeto criar; quem calcula o XP é o próprio objeto
        SessaoEstudo sessao;
        string modalidade = cmbModalidade.SelectedItem?.ToString() ?? "Pomodoro";
        if (modalidade == "Exercicios")
            sessao = new SessaoExercicios(disciplina, minutos, (int)numTotalQuestoes.Value, extra);
        else if (modalidade == "Leitura")
            sessao = new SessaoLeitura(disciplina, minutos, extra, chkResumo.Checked);
        else
            sessao = new SessaoPomodoro(disciplina, minutos, extra);

        discente.RegistrarEstudo(sessao);     // soma XP (Missão 5, forma 1)
        meta.RegistrarAvanco(minutos);        // soma minutos com validação (Missão 2)
        lstHistorico.Items.Add(sessao.GerarFeedback());
        AtualizarTela();

        // Missão 10: grava no backend (POST /api/sessoes)
        btnRegistrar.Enabled = false;
        lblStatus.Text = "Enviando sessão para o backend...";
        bool salvou = await backend.SalvarSessaoAsync(discente, sessao);
        lblStatus.Text = salvou
            ? "Sessão salva no backend (POST /api/sessoes)."
            : "Sessão registrada só na memória: backend offline.";
        btnRegistrar.Enabled = true;
    }

    // Missão 8 + 9: o serviço usa o canal escolhido (qualquer INotificador)
    private void BtnNotificar_Click(object? sender, EventArgs e)
    {
        INotificador canal = notificadores[cmbCanal.SelectedIndex];
        string resultado = servicoAlerta.AvaliarDiscente(discente, meta, responsavel, canal);
        MessageBox.Show(resultado, "Notificar Responsável", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    // Missão 10: GET /api/relatorio/{nome}
    private async void BtnCarregarServidor_Click(object? sender, EventArgs e)
    {
        btnCarregarServidor.Enabled = false;
        txtServidor.Text = "Buscando dados no servidor...";
        List<string> linhas = await backend.BuscarRelatorioAsync(discente.GetNome());
        txtServidor.Lines = linhas.ToArray();
        btnCarregarServidor.Enabled = true;
    }

    // Mostra o resultado dos testes de mesa das Missões 1 a 8
    private void BtnRodarTestes_Click(object? sender, EventArgs e)
    {
        string texto = TesteMissoes.Executar().Replace("\r\n", "\n").Replace("\n", "\r\n");

        Form janela = new Form
        {
            Text = "Testes das Missões 1 a 8",
            Size = new Size(900, 650),
            StartPosition = FormStartPosition.CenterParent
        };
        TextBox caixa = new TextBox
        {
            Multiline = true,
            ReadOnly = true,
            ScrollBars = ScrollBars.Both,
            WordWrap = false,
            Dock = DockStyle.Fill,
            Font = new Font("Consolas", 10F),
            Text = texto
        };
        janela.Controls.Add(caixa);
        janela.ShowDialog(this);
    }

    // =================================================================
    // Pequenos ajudantes de layout
    // =================================================================
    private static GroupBox Grupo(string titulo, int x, int y, int largura, int altura)
    {
        return new GroupBox
        {
            Text = titulo,
            Location = new Point(x, y),
            Size = new Size(largura, altura)
        };
    }

    private static Label Rotulo(string texto, int x, int y)
    {
        return new Label
        {
            Text = texto,
            Location = new Point(x, y),
            AutoSize = true
        };
    }

    private static void Posicionar(Control c, int x, int y, int largura, int altura)
    {
        c.Location = new Point(x, y);
        c.Size = new Size(largura, altura);
    }

    private static void EstilizarBotao(Button b, Color cor)
    {
        b.FlatStyle = FlatStyle.Flat;
        b.FlatAppearance.BorderSize = 0;
        b.BackColor = cor;
        b.ForeColor = Color.White;
        b.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        b.Cursor = Cursors.Hand;
    }
}
