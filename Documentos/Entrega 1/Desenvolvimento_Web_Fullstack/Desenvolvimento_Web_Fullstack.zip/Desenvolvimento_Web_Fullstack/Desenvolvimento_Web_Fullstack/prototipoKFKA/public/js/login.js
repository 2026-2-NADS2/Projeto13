/* ============================================================
   Lógica da tela de login (public/js/login.js)
   Página: /html/login/login.html

   O QUE ESTE ARQUIVO FAZ
   1. Escuta o envio do formulário (#form-login).
   2. Confere os campos ANTES de chamar a API:
        - e-mail: obrigatório e no formato nome@exemplo.com
        - senha: obrigatória
   3. Se estiver tudo certo, envia POST /api/login.
   4. Durante o envio, desabilita o botão e mostra "Entrando..."
      (é o "carregamento visível" da E1).
   5. Se der certo, guarda o usuário e vai para a página do perfil.
      Se der errado, mostra a mensagem na tela (erro visível).

   DEPENDE DE: comum.js (salvarUsuario, paginaInicialDoPerfil,
   buscarJSON). Na página, carregue nesta ordem:
     <script src="/js/comum.js" defer></script>
     <script src="/js/login.js" defer></script>

   CONTRATO COMBINADO DA API
   Pedido : POST /api/login  (JSON)  { "email": "...", "senha": "..." }
   Sucesso: 200  { "usuario": { "id": 2, "nome": "Carla Lima", "perfil": "professor" } }
   Erros  : 400 { "erro": "Informe e-mail e senha." }
            401 { "erro": "E-mail ou senha inválidos." }
            500 { "erro": "..." }
   ============================================================ */

'use strict';


/* ------------------------------------------------------------
   1. ELEMENTOS DA PÁGINA
   Buscamos cada elemento UMA vez e guardamos em variáveis.
   getElementById procura pelo atributo id do HTML.
   ------------------------------------------------------------ */
const formLogin = document.getElementById('form-login');
const campoEmail = document.getElementById('email');
const campoSenha = document.getElementById('senha');
const erroEmail = document.getElementById('erro-email');
const erroSenha = document.getElementById('erro-senha');
const mensagemGeral = document.getElementById('mensagem-geral');
const botaoEntrar = document.getElementById('botao-entrar');

// Texto original do botão, guardado para restaurar depois do envio.
const TEXTO_BOTAO = botaoEntrar.textContent;


/* ------------------------------------------------------------
   2. FUNÇÕES DE ERRO (mostrar e limpar)
   O CSS já pinta de vermelho o que tiver aria-invalid="true" e os
   <span id="erro-...">; o JS só escreve o texto e marca o campo.
   ------------------------------------------------------------ */

// Mostra o erro de UM campo: escreve a mensagem e marca o campo.
function mostrarErroCampo(campo, spanErro, mensagem) {
  spanErro.textContent = mensagem;
  campo.setAttribute('aria-invalid', 'true');
}

// Limpa o erro de UM campo. (Sem texto, o span some sozinho pelo CSS.)
function limparErroCampo(campo, spanErro) {
  spanErro.textContent = '';
  campo.removeAttribute('aria-invalid');
}

// Mostra a mensagem geral (erro de login ou de conexão).
function mostrarMensagemGeral(texto) {
  mensagemGeral.textContent = texto;
  mensagemGeral.hidden = false;   // hidden = false faz o elemento aparecer
}

function esconderMensagemGeral() {
  mensagemGeral.textContent = '';
  mensagemGeral.hidden = true;
}


/* ------------------------------------------------------------
   3. VALIDAÇÃO DOS CAMPOS
   Devolve true se estiver tudo certo, false se houver algum erro.
   Mostra TODOS os erros de uma vez (não só o primeiro), e leva o
   foco para o primeiro campo com problema (ajuda quem usa teclado
   ou leitor de tela).
   ------------------------------------------------------------ */

// Expressão regular simples de e-mail: "algo" + "@" + "algo" + "." + "algo",
// sem espaços. (O backend também valida: nunca confie só no front-end.)
const FORMATO_EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function validarFormulario() {
  let valido = true;
  let primeiroCampoComErro = null;

  // trim() tira espaços do começo e do fim. Ex.: "  " vira "" (vazio).
  const email = campoEmail.value.trim();
  const senha = campoSenha.value;   // a senha NÃO leva trim: espaços podem fazer parte dela

  // ---- E-mail ----
  if (email === '') {
    mostrarErroCampo(campoEmail, erroEmail, 'Informe seu e-mail.');
    valido = false;
    primeiroCampoComErro = primeiroCampoComErro || campoEmail;
  } else if (!FORMATO_EMAIL.test(email)) {
    mostrarErroCampo(campoEmail, erroEmail, 'Digite um e-mail válido, como nome@exemplo.com.');
    valido = false;
    primeiroCampoComErro = primeiroCampoComErro || campoEmail;
  }

  // ---- Senha ----
  if (senha === '') {
    mostrarErroCampo(campoSenha, erroSenha, 'Informe sua senha.');
    valido = false;
    primeiroCampoComErro = primeiroCampoComErro || campoSenha;
  }

  // Foco no primeiro campo com erro.
  if (primeiroCampoComErro) primeiroCampoComErro.focus();

  return valido;
}


/* ------------------------------------------------------------
   4. ESTADO "ENVIANDO"
   Trava o botão para a pessoa não clicar duas vezes (o que
   mandaria o pedido em duplicidade) e avisa que está carregando.
   ------------------------------------------------------------ */
function definirEnviando(enviando) {
  botaoEntrar.disabled = enviando;
  botaoEntrar.textContent = enviando ? 'Entrando...' : TEXTO_BOTAO;
}


/* ------------------------------------------------------------
   5. ENVIO DO FORMULÁRIO
   "async" permite usar "await": o código espera a resposta da API
   sem travar a página.
   ------------------------------------------------------------ */
async function aoEnviar(evento) {
  // Impede o comportamento padrão do formulário (recarregar a página
  // e enviar os dados na URL). Quem controla o envio agora é o JS.
  evento.preventDefault();

  // Começa "limpando" mensagens da tentativa anterior.
  limparErroCampo(campoEmail, erroEmail);
  limparErroCampo(campoSenha, erroSenha);
  esconderMensagemGeral();

  // Se a validação falhar, PARA aqui: a API nem é chamada.
  if (!validarFormulario()) return;

  definirEnviando(true);

  try {
    // Chama a API. JSON.stringify transforma o objeto em texto JSON.
    const dados = await buscarJSON('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: campoEmail.value.trim(),
        senha: campoSenha.value,
      }),
    });

    // Sucesso: guarda o usuário e vai para a página do perfil.
    salvarUsuario(dados.usuario);
    window.location.href = paginaInicialDoPerfil(dados.usuario.perfil);
    // (não reabilitamos o botão: a página vai mudar em instantes)
    return;
  } catch (erro) {
    // Erro de login (401), de validação (400), do servidor (500) ou
    // de conexão. buscarJSON já entrega a mensagem pronta.
    mostrarMensagemGeral(erro.message);
  }

  // Só chega aqui se deu erro: libera o botão para tentar de novo.
  definirEnviando(false);
}


/* ------------------------------------------------------------
   6. LIGAR OS EVENTOS
   ------------------------------------------------------------ */

// "submit" dispara ao clicar em Entrar OU ao apertar Enter num campo.
formLogin.addEventListener('submit', aoEnviar);

// Enquanto a pessoa corrige o campo, o erro dele some
// (feedback imediato, sem esperar o próximo envio).
campoEmail.addEventListener('input', () => limparErroCampo(campoEmail, erroEmail));
campoSenha.addEventListener('input', () => limparErroCampo(campoSenha, erroSenha));
