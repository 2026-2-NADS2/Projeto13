// Jogador herda de Entidade e adiciona comportamento próprio:
// mover-se nos 4 sentidos com o teclado, atirar para a direita
// e SINALIZAR VISUALMENTE quando leva dano (pisca em vermelho).
class Jogador extends Entidade {
  constructor(x, y) {
    super(x, y, 30, 56, '#7CFC00'); // sprite do canhão girado: mais alto que largo
    this.velocidade = 6;
    this.vidas = 3;
    this.cooldownTiro = 0; // evita metralhar tiros infinitos

    // NOVO: contador regressivo do efeito de dano, medido em "frames" (1 frame = 1/60 s).
    // 0 = nave normal; maior que 0 = nave piscando em vermelho.
    // Fica guardado DENTRO do Jogador (encapsulamento): só ele sabe como se mostra o dano.
    this.tempoDano = 0;
  }

  // direcaoX / direcaoY: -1, 0 ou 1 (esquerda/cima = -1, direita/baixo = 1)
  mover(direcaoX, direcaoY, larguraCanvas, alturaCanvas) {
    // Na diagonal o jogador andaria ~41% mais rápido (soma dos dois eixos);
    // multiplicar por 0,7071 mantém a mesma velocidade em qualquer direção.
    const fator = direcaoX !== 0 && direcaoY !== 0 ? Math.SQRT1_2 : 1;
    this.x += this.velocidade * direcaoX * fator;
    this.y += this.velocidade * direcaoY * fator;

    // Não deixa o jogador sair da tela
    this.x = Math.max(0, Math.min(this.x, larguraCanvas - this.largura));
    this.y = Math.max(0, Math.min(this.y, alturaCanvas - this.altura));
  }

  atirar(listaProjeteis) {
    if (this.cooldownTiro > 0) return;

    // O tiro sai da "ponta" da nave (lado direito), na altura do meio
    const pontaX = this.x + this.largura;
    const meioY = this.y + this.altura / 2 - 2;
    listaProjeteis.push(new Projetil(pontaX, meioY, 1, '#7CFC00'));
    this.cooldownTiro = 15; // frames até poder atirar de novo
  }

  // NOVO: o que acontece quando a nave é atingida (por tiro ou por choque com invasor).
  // Antes, o Jogo fazia "jogador.vidas--" direto, de fora. Agora o Jogo apenas
  // AVISA ("você foi atingido") e o próprio Jogador decide o que fazer:
  // perde uma vida E liga o efeito visual. Se um dia surgir outro efeito
  // (invencibilidade, tremer a tela...), a mudança fica só aqui.
  receberDano() {
    this.vidas--;
    this.tempoDano = Jogador.DURACAO_DANO; // (re)inicia o efeito; se levar outro tiro, recomeça
  }

  // Sobrescreve desenhar() da Entidade: desenha o canhão virado para a direita.
  // ALTERADO: a cor agora pode mudar durante o efeito de dano.
  desenhar(ctx) {
    let cor = this.cor; // cor normal (verde)

    if (this.tempoDano > 0) {
      // Quantos frames se passaram desde o dano (0, 1, 2, ...).
      const decorrido = Jogador.DURACAO_DANO - this.tempoDano;
      // A cada INTERVALO_PISCADA frames alterna entre vermelho (par) e verde (ímpar).
      // Usar "decorrido" (e não "tempoDano") faz o efeito COMEÇAR em vermelho
      // e TERMINAR na cor normal.
      const fase = Math.floor(decorrido / Jogador.INTERVALO_PISCADA);
      if (fase % 2 === 0) cor = Jogador.COR_DANO;
    }

    // Usamos uma variável local em vez de mudar this.cor: assim a cor "verdadeira"
    // da nave nunca se perde e não há risco de ela ficar vermelha para sempre.
    Sprites.desenhar(ctx, Sprites.PARA_DIREITA.CANHAO[0], this.x, this.y, this.largura, this.altura, cor);
  }

  // Sobrescreve atualizar() da classe base: além de existir,
  // o jogador precisa contar o cooldown do tiro a cada frame.
  // ALTERADO: também faz o efeito de dano "andar" até acabar.
  atualizar() {
    if (this.cooldownTiro > 0) this.cooldownTiro--;
    if (this.tempoDano > 0) this.tempoDano--;
  }
}

// NOVO: constantes do efeito de dano. Ficam na CLASSE (static, como Barreira.TAMANHO)
// para os números não ficarem "soltos" no meio do código e serem fáceis de ajustar.
Jogador.DURACAO_DANO = 48;       // duração total do efeito: 48 frames = 0,8 segundo
Jogador.INTERVALO_PISCADA = 6;   // troca de cor a cada 6 frames (4 trocas de cor no total)
Jogador.COR_DANO = '#ff2a2a';    // vermelho do efeito
