// Jogador herda de Entidade e adiciona comportamento próprio:
// mover-se nos 4 sentidos com o teclado e atirar para a direita.
class Jogador extends Entidade {
  constructor(x, y) {
    super(x, y, 30, 56, '#7CFC00'); // sprite do canhão girado: mais alto que largo
    this.velocidade = 6;
    this.vidas = 3;
    this.cooldownTiro = 0; // evita metralhar tiros infinitos
  }

  // direcaoX / direcaoY: -1, 0 ou 1 (esquerda/cima = -1, direita/baixo = 1)
  mover(direcaoX, direcaoY, larguraCanvas, alturaCanvas) {
    // Na diagonal o jogador andaria ~41% mais rápido (soma dos dois eixos);
    // multiplicar por 0,7071 mantém a mesma velocidade em qualquer direção.
    const fator = direcaoX !== 0 && direcaoY !== 0 ? Math.SQRT1_2 : 1;
    this.x += this.velocidade * direcaoX * fator;
    this.y += this.velocidade * direcaoY * fator;

    // Não deixa o jogador sair da tela
    this.x = Math.max(0, Math.min(this.x, larguraCanvas - this.largura));
    this.y = Math.max(0, Math.min(this.y, alturaCanvas - this.altura));
  }

  atirar(listaProjeteis) {
    if (this.cooldownTiro > 0) return;

    // O tiro sai da "ponta" da nave (lado direito), na altura do meio
    const pontaX = this.x + this.largura;
    const meioY = this.y + this.altura / 2 - 2;
    listaProjeteis.push(new Projetil(pontaX, meioY, 1, '#7CFC00'));
    this.cooldownTiro = 15; // frames até poder atirar de novo
  }

  // Sobrescreve desenhar() da Entidade: desenha o canhão virado para a direita.
  desenhar(ctx) {
    Sprites.desenhar(ctx, Sprites.PARA_DIREITA.CANHAO[0], this.x, this.y, this.largura, this.altura, this.cor);
  }

  // Sobrescreve atualizar() da classe base: além de existir,
  // o jogador precisa contar o cooldown do tiro a cada frame.
  atualizar() {
    if (this.cooldownTiro > 0) this.cooldownTiro--;
  }
}
