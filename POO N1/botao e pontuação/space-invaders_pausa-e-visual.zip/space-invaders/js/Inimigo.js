// Inimigo é a classe base para todos os tipos de invasor.
// Ela guarda o que é comum (movimento em bloco, pontos, vida)
// e deixa o comportamento específico (atualizar / atirar) para as
// subclasses sobrescreverem -> é aqui que o POLIMORFISMO acontece:
// o Jogo trata todo mundo como "Inimigo", mas cada um se comporta diferente.
class Inimigo extends Entidade {
  constructor(x, y, largura, altura, cor, pontos) {
    super(x, y, largura, altura, cor);
    this.pontos = pontos;
    this.direcao = 1; // 1 = direita, -1 = esquerda (movimento em bloco)
    this.quadros = null; // desenhos do inimigo (Sprites); cada subclasse escolhe os seus
  }

  // O inimigo "anda": alterna entre os 2 quadros do desenho conforme se desloca.
  quadroAtual() {
    return Math.floor(Math.abs(this.x) / 10) % 2;
  }

  // Sobrescreve desenhar() da Entidade: em vez de um retângulo, desenha o alien
  // da subclasse (lula, caranguejo ou polvo) -> POLIMORFISMO pelos dados de cada filha.
  desenhar(ctx) {
    Sprites.desenhar(ctx, this.quadros[this.quadroAtual()], this.x, this.y, this.largura, this.altura, this.cor);
  }

  // Comportamento padrão de movimento em bloco (usado como base;
  // as subclasses podem chamar super.mover() e completar com o extra delas).
  mover(velocidadeBase, larguraCanvas, alturaQueda) {
    this.x += velocidadeBase * this.direcao;

    // Se bateu na borda, quem chama esse método decide inverter a direção
    // e descer a fileira toda (isso fica no Jogo.js, pois afeta o grupo inteiro).
  }

  // Método "gancho" que cada subclasse pode sobrescrever para atirar
  // com sua própria lógica/chance. Por padrão, um inimigo comum não atira.
  tentarAtirar(listaProjeteis) {
    // Implementação vazia: nem todo inimigo atira.
  }
}
