// Musica: toca uma música de fundo em loop, SINTETIZADA na hora (sem arquivos de áudio,
// sem direitos autorais). É uma sequência curta de 4 compassos em lá menor
// (Am - F - C - G): um baixo marcando o ritmo e um arpejo por cima.
// Usa o mesmo sistema de áudio da classe Som (contexto e volume geral).
//
// Como o tempo é preciso: um "agendador" roda a cada 50 ms e programa as notas dos
// próximos 0,25 s no relógio do áudio, que não atrasa nem trava como o do JavaScript.
class Musica {
  constructor(som) {
    this.som = som;
    this.ligada = true;  // o jogador pode desligar só a música (tecla N)
    this.passo = 0;      // posição no loop (cada passo é uma colcheia)
    this.andamento = 100; // batidas por minuto; o Jogo aumenta a cada horda
    this.proximoTempo = 0; // momento (no relógio do áudio) da próxima nota
    this.timer = null;     // agendador; null = música parada
    this.saida = null;     // controle de volume da música
  }

  // Começa a tocar (ou só atualiza o andamento, se já estiver tocando).
  tocar(andamento) {
    this.andamento = andamento;
    const ctx = this.som.contexto;
    if (this.timer || !ctx) return;

    if (!this.saida) {
      this.saida = ctx.createGain();
      this.saida.gain.value = 0.8;
      this.saida.connect(this.som.mestre);
    }
    this.proximoTempo = ctx.currentTime + 0.1;
    this.timer = setInterval(() => this._agendar(), 50);
  }

  // Para de tocar, mas guarda onde estava (a música continua do mesmo ponto).
  parar() {
    clearInterval(this.timer);
    this.timer = null;
  }

  // Volta ao começo do loop (usado quando uma partida nova começa).
  reiniciar() {
    this.parar();
    this.passo = 0;
  }

  // Programa todas as notas que cairem nos próximos 0,25 s.
  _agendar() {
    const ctx = this.som.contexto;
    while (this.proximoTempo < ctx.currentTime + 0.25) {
      this._tocarPasso(this.passo, this.proximoTempo);
      this.proximoTempo += 60 / this.andamento / 2; // duração de uma colcheia
      this.passo = (this.passo + 1) % Musica.TAMANHO_DO_LOOP;
    }
  }

  // Cada compasso tem 8 passos: baixo nos tempos pares e arpejo em todos.
  _tocarPasso(passo, quando) {
    const acorde = Musica.ACORDES[Math.floor(passo / 8) % Musica.ACORDES.length];
    const tempo = passo % 8;

    if (tempo % 2 === 0) this._nota('square', acorde.baixo, quando, 0.2, 0.22);
    this._nota('triangle', acorde.arpejo[tempo % 4], quando, 0.16, 0.15);
  }

  // Toca uma nota curta: sobe rápido e some aos poucos (envelope).
  _nota(tipo, frequencia, quando, duracao, ganho) {
    const ctx = this.som.contexto;
    const oscilador = ctx.createOscillator();
    const volume = ctx.createGain();

    oscilador.type = tipo;
    oscilador.frequency.value = frequencia;
    volume.gain.setValueAtTime(0.001, quando);
    volume.gain.exponentialRampToValueAtTime(ganho, quando + 0.01);
    volume.gain.exponentialRampToValueAtTime(0.001, quando + duracao);

    oscilador.connect(volume);
    volume.connect(this.saida);
    oscilador.start(quando);
    oscilador.stop(quando + duracao + 0.02);
  }
}

Musica.TAMANHO_DO_LOOP = 32; // 4 compassos de 8 passos

// Acordes do loop: nota do baixo e 4 notas do arpejo (frequências em Hz).
Musica.ACORDES = [
  { baixo: 220.0,  arpejo: [440.0, 523.25, 659.25, 523.25] },  // Lá menor (Am)
  { baixo: 174.61, arpejo: [349.23, 440.0, 523.25, 440.0] },   // Fá maior (F)
  { baixo: 261.63, arpejo: [523.25, 659.25, 783.99, 659.25] }, // Dó maior (C)
  { baixo: 196.0,  arpejo: [392.0, 493.88, 587.33, 493.88] },  // Sol maior (G)
];
