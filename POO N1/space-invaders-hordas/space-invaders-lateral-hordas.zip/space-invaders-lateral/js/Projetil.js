// Projetil representa tanto o tiro do jogador quanto o tiro dos inimigos.
// Na versão LATERAL o tiro viaja na horizontal (eixo X):
// o parâmetro "direcao" define se ele vai para a direita (1) ou para a esquerda (-1).
class Projetil extends Entidade {
  constructor(x, y, direcao, cor = '#ffffff') {
    super(x, y, 12, 4, cor); // largura 12 e altura 4: um "traço" deitado
    this.velocidade = 9;
    this.direcao = direcao; // 1 = vai para a direita (jogador), -1 = vai para a esquerda (inimigo)
  }

  // larguraCanvas: o Jogo informa o tamanho atual da tela (ela agora muda conforme a janela)
  atualizar(larguraCanvas) {
    this.x += this.velocidade * this.direcao;

    // Saiu da tela -> desativa para ser removido do jogo
    if (this.x + this.largura < 0 || this.x > larguraCanvas) {
      this.ativo = false;
    }
  }
}
