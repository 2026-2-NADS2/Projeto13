// Inimigo atirador: sobrescreve tentarAtirar() para de fato disparar
// projéteis contra o jogador, algo que o Inimigo base não faz.
class InimigoAtirador extends Inimigo {
  constructor(x, y) {
    super(x, y, 32, 24, '#c266ff', 30);
    this.chanceDeAtirar = 0.002; // chance por frame de disparar
    this.quadros = Sprites.LULA; // visual da lula
  }

  tentarAtirar(listaProjeteis) {
    if (Math.random() < this.chanceDeAtirar) {
      // O tiro sai da frente (lado esquerdo) do inimigo e vai para a esquerda
      const frenteX = this.x - 12;
      const meioY = this.y + this.altura / 2 - 2;
      listaProjeteis.push(new Projetil(frenteX, meioY, -1, '#c266ff'));
    }
  }
}
