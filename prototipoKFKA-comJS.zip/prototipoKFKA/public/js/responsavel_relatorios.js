/* ============================================================
   KFKA - Lista de relatórios do Responsável
   (public/js/responsavel_relatorios.js)
   Página: /html/responsavel/responsavel_relatorios_filtro.html

   O QUE ESTE ARQUIVO FAZ (requisito da E1: "consumo de dados de
   forma assíncrona, com tratamento visível de erro/carregamento")
   1. Busca os relatórios publicados em GET /api/relatorios.
   2. Enquanto espera a resposta, mostra "Carregando..." na tabela.
   3. Se der certo, monta as linhas da tabela; se não houver
      resultados, mostra "Nenhum relatório encontrado".
   4. Se a API falhar, mostra a mensagem de erro na própria tabela.
   5. Filtros (aluno, ano, bimestre, disciplina) atualizam a tabela
      SEM recarregar a página.
   6. Paginação: botões Anterior/Próxima e o texto "Página 1 de 2".

   DEPENDE DE: comum.js (buscarJSON, criarCelula, criarCelulaComLink,
   mostrarMensagemNaTabela, formatarData, formatarMedia).
   Na página, carregue nesta ordem:
     <script src="/js/comum.js" defer></script>
     <script src="/js/responsavel_relatorios.js" defer></script>

   RESPOSTA DA API (já pronta no server.js)
   {
     pagina, porPagina, total, totalPaginas,
     relatorios: [ { id, alunoId, aluno, turma, disciplina,
                     professor, bimestre, anoLetivo, media, publicadoEm } ]
   }
   ============================================================ */

'use strict';


/* ------------------------------------------------------------
   1. ELEMENTOS DA PÁGINA
   ------------------------------------------------------------ */
const formFiltros = document.getElementById('form-filtros');
const filtroAluno = document.getElementById('filtro-aluno');
const filtroAno = document.getElementById('filtro-ano');
const filtroBimestre = document.getElementById('filtro-bimestre');
const filtroDisciplina = document.getElementById('filtro-disciplina');

const resumoResultados = document.getElementById('resumo-resultados');
const tabelaRelatorios = document.getElementById('tabela-relatorios');   // <tbody>

const botaoAnterior = document.getElementById('pagina-anterior');
const botaoProxima = document.getElementById('pagina-proxima');
const textoPagina = document.getElementById('pagina-atual');

// A tabela tem 7 colunas (Aluno, Disciplina, Bimestre, Professor,
// Média, Publicado em, Ações). Usado no colspan das mensagens.
const COLUNAS = 7;


/* ------------------------------------------------------------
   2. ESTADO DA PÁGINA
   Variáveis que "lembram" em que ponto estamos.
   ------------------------------------------------------------ */
let paginaAtual = 1;
let totalPaginas = 1;

// Contador de buscas. Se a pessoa clicar em "Filtrar" várias vezes
// rápido, duas respostas podem voltar fora de ordem. Só a resposta
// da busca MAIS RECENTE pode atualizar a tela.
let numeroDaUltimaBusca = 0;


/* ------------------------------------------------------------
   3. MONTAR O ENDEREÇO DA API COM OS FILTROS
   URLSearchParams monta a parte "?aluno=1&bimestre=3" e já
   codifica caracteres especiais (ex.: acentos e espaços).
   Só entram os filtros preenchidos.
   ------------------------------------------------------------ */
function montarEndereco(pagina) {
  const parametros = new URLSearchParams();

  if (filtroAluno.value) parametros.set('aluno', filtroAluno.value);
  if (filtroAno.value) parametros.set('ano_letivo', filtroAno.value);
  if (filtroBimestre.value) parametros.set('bimestre', filtroBimestre.value);
  if (filtroDisciplina.value) parametros.set('disciplina', filtroDisciplina.value);
  parametros.set('pagina', pagina);

  return '/api/relatorios?' + parametros.toString();
}


/* ------------------------------------------------------------
   4. DESENHAR OS RESULTADOS NA TELA
   ------------------------------------------------------------ */

// Cria uma linha <tr> da tabela para UM relatório.
function criarLinha(relatorio) {
  const tr = document.createElement('tr');

  // Endereço da página de detalhe. encodeURIComponent protege o id
  // caso ele tenha algum caractere especial.
  const enderecoDetalhe =
    '/html/responsavel/responsavel_relatorio.html?id=' + encodeURIComponent(relatorio.id);

  // Texto que o leitor de tela lê no link (diferente em cada linha).
  const textoAcessivel =
    'Ver relatório de ' + relatorio.disciplina + ' de ' + relatorio.aluno;

  // A ORDEM das células segue a ordem das colunas do <thead> do HTML.
  tr.appendChild(criarCelula(relatorio.aluno));
  tr.appendChild(criarCelula(relatorio.disciplina));
  tr.appendChild(criarCelula(relatorio.bimestre + 'º bimestre'));
  tr.appendChild(criarCelula(relatorio.professor));
  tr.appendChild(criarCelula(formatarMedia(relatorio.media)));
  tr.appendChild(criarCelula(formatarData(relatorio.publicadoEm)));
  tr.appendChild(criarCelulaComLink('Ver relatório', enderecoDetalhe, textoAcessivel));

  return tr;
}

// Escreve "12 relatórios encontrados" (com singular/plural certo).
function atualizarResumo(total) {
  if (total === 1) {
    resumoResultados.textContent = '1 relatório encontrado';
  } else {
    resumoResultados.textContent = total + ' relatórios encontrados';
  }
}

// Atualiza "Página 1 de 2" e habilita/desabilita os botões.
function atualizarPaginacao() {
  textoPagina.textContent = 'Página ' + paginaAtual + ' de ' + totalPaginas;
  botaoAnterior.disabled = paginaAtual <= 1;
  botaoProxima.disabled = paginaAtual >= totalPaginas;
}

// Desabilita os dois botões (usado enquanto carrega, para evitar
// cliques repetidos).
function travarPaginacao() {
  botaoAnterior.disabled = true;
  botaoProxima.disabled = true;
}


/* ------------------------------------------------------------
   5. BUSCAR OS RELATÓRIOS
   É aqui que acontecem os 3 estados visíveis pedidos pela E1:
   CARREGANDO -> SUCESSO (ou vazio) -> ERRO
   ------------------------------------------------------------ */
async function buscarRelatorios(pagina) {
  // Anota o número desta busca (veja a explicação em "ESTADO").
  numeroDaUltimaBusca += 1;
  const minhaBusca = numeroDaUltimaBusca;

  // ---- Estado 1: CARREGANDO ----
  mostrarMensagemNaTabela(tabelaRelatorios, COLUNAS, 'Carregando...', false);
  resumoResultados.textContent = '';
  travarPaginacao();

  try {
    const dados = await buscarJSON(montarEndereco(pagina));

    // Se, enquanto esperávamos, outra busca foi iniciada, esta
    // resposta está velha: descarta.
    if (minhaBusca !== numeroDaUltimaBusca) return;

    // Guarda onde estamos. A API devolve a página que realmente usou.
    paginaAtual = dados.pagina;
    totalPaginas = dados.totalPaginas;

    atualizarResumo(dados.total);

    // ---- Estado 2a: SUCESSO, mas SEM resultados ----
    if (dados.relatorios.length === 0) {
      mostrarMensagemNaTabela(tabelaRelatorios, COLUNAS, 'Nenhum relatório encontrado.', false);
    } else {
      // ---- Estado 2b: SUCESSO com resultados ----
      // Cria todas as linhas e troca o conteúdo do <tbody> de uma vez.
      // map() cria uma <tr> para cada relatório; o "..." espalha a lista.
      tabelaRelatorios.replaceChildren(...dados.relatorios.map(criarLinha));
    }

    atualizarPaginacao();
  } catch (erro) {
    if (minhaBusca !== numeroDaUltimaBusca) return;

    // ---- Estado 3: ERRO VISÍVEL ----
    // erro.message traz o texto da API (ex.: "Não foi possível carregar
    // os relatórios. Tente novamente.") ou o de falha de conexão.
    mostrarMensagemNaTabela(tabelaRelatorios, COLUNAS, erro.message, true);
    resumoResultados.textContent = '';

    // Mantém os botões travados, exceto "Anterior" se já estávamos
    // depois da página 1 (assim dá para voltar).
    paginaAtual = Math.max(1, paginaAtual);
    textoPagina.textContent = 'Página ' + paginaAtual;
    botaoAnterior.disabled = paginaAtual <= 1;
    botaoProxima.disabled = true;
  }
}


/* ------------------------------------------------------------
   6. PREENCHER OS FILTROS "Aluno" E "Disciplina"
   Os <option> dependem de quem está logado, então são criados
   pelo JS (o HTML só tem "Todos").

   ATENÇÃO (E1): a API que devolve só os alunos do responsável
   (GET /api/responsavel/alunos) ainda não existe. Por enquanto
   montamos as opções a partir dos relatórios que a rota pronta
   devolve (sem filtros). Na E2, troque por chamadas às rotas
   próprias de alunos e disciplinas.
   ------------------------------------------------------------ */

// Cria um <option> e o coloca no <select>.
function adicionarOpcao(select, valor, texto) {
  const opcao = document.createElement('option');
  opcao.value = valor;
  opcao.textContent = texto;
  select.appendChild(opcao);
}

async function carregarOpcoesDosFiltros() {
  try {
    const dados = await buscarJSON('/api/relatorios?pagina=1');

    // Map guarda pares id -> nome e NÃO repete: se o mesmo aluno
    // aparece em vários relatórios, entra uma vez só.
    const alunos = new Map();
    const disciplinas = new Set();

    dados.relatorios.forEach((r) => {
      alunos.set(String(r.alunoId), r.aluno);
      disciplinas.add(r.disciplina);
    });

    // Ordem alfabética em português (localeCompare entende acentos).
    [...alunos.entries()]
      .sort((a, b) => a[1].localeCompare(b[1], 'pt-BR'))
      .forEach(([id, nome]) => adicionarOpcao(filtroAluno, id, nome));

    [...disciplinas]
      .sort((a, b) => a.localeCompare(b, 'pt-BR'))
      .forEach((nome) => adicionarOpcao(filtroDisciplina, nome, nome));
  } catch (erro) {
    // Se falhar, os filtros ficam só com "Todos". A tabela principal
    // tem o próprio tratamento de erro, então não repetimos a mensagem.
    console.error('Não foi possível carregar as opções dos filtros:', erro);
  }
}

// Se a página foi aberta com ?aluno=15 (link "Ver relatórios" do
// painel), deixa esse aluno selecionado no filtro.
function preSelecionarAlunoDaURL() {
  // Lê o parâmetro "aluno" da barra de endereço.
  const alunoDaURL = new URLSearchParams(window.location.search).get('aluno');
  if (!alunoDaURL) return;

  // Se o aluno não veio na lista de opções, cria uma opção genérica
  // para o filtro ainda funcionar.
  const existe = [...filtroAluno.options].some((o) => o.value === alunoDaURL);
  if (!existe) adicionarOpcao(filtroAluno, alunoDaURL, 'Aluno selecionado');

  filtroAluno.value = alunoDaURL;
}


/* ------------------------------------------------------------
   7. EVENTOS
   ------------------------------------------------------------ */

// Botão "Filtrar" (submit). preventDefault impede o recarregamento
// da página; em vez disso, refazemos a busca a partir da página 1.
formFiltros.addEventListener('submit', (evento) => {
  evento.preventDefault();
  buscarRelatorios(1);
});

// Botão "Limpar filtros" (reset). O navegador só devolve os campos
// aos valores iniciais DEPOIS deste evento; o setTimeout(..., 0)
// espera isso acontecer para então refazer a busca.
formFiltros.addEventListener('reset', () => {
  setTimeout(() => buscarRelatorios(1), 0);
});

botaoAnterior.addEventListener('click', () => buscarRelatorios(paginaAtual - 1));
botaoProxima.addEventListener('click', () => buscarRelatorios(paginaAtual + 1));


/* ------------------------------------------------------------
   8. INICIALIZAÇÃO
   Ao abrir a página: primeiro montamos os filtros (e escolhemos o
   aluno da URL); só então buscamos a tabela já com esses filtros.
   ------------------------------------------------------------ */
async function iniciar() {
  await carregarOpcoesDosFiltros();
  preSelecionarAlunoDaURL();
  await buscarRelatorios(1);
}

iniciar();
