const canvas = document.getElementById('jogoCanvas');
const ctx = canvas.getContext('2d');

// ---------------------------------------------------------
// PROGRAMAÇÃO ORIENTADA A OBJETOS: Classes e Herança
// ---------------------------------------------------------

// Classe Base (Superclasse)
class EntidadeJogo {
    constructor(x, y, largura, altura, cor) {
        this.x = x;
        this.y = y;
        this.largura = largura;
        this.altura = altura;
        this.cor = cor;
    }

    // Método base a ser sobrescrito (Polimorfismo)
    atualizar() {
        // Comportamento genérico ou vazio
    }

    desenhar(ctx) {
        ctx.fillStyle = this.cor;
        ctx.fillRect(this.x, this.y, this.largura, this.altura);
    }
}

// Subclasse Jogador (Herança)
class Jogador extends EntidadeJogo {
    constructor(x, y) {
        super(x, y, 30, 30, '#00ff00');
        this.velocidade = 4;
        this.teclas = {};

        // Captura de eventos do teclado
        window.addEventListener('keydown', (e) => this.teclas[e.code] = true);
        window.addEventListener('keyup', (e) => this.teclas[e.code] = false);
    }

    // Polimorfismo: Comportamento específico de movimento do jogador
    atualizar() {
        if (this.teclas['ArrowLeft'] && this.x > 0) {
            this.x -= this.velocidade;
        }
        if (this.teclas['ArrowRight'] && this.x + this.largura < canvas.width) {
            this.x += this.velocidade;
        }
    }
}

// Subclasse Inimigo (Herança)
class Inimigo extends EntidadeJogo {
    constructor(x, y) {
        super(x, y, 20, 20, '#ff0000');
        this.velocidadeX = 1.5;
        this.direcao = 1; // 1 = direita, -1 = esquerda
    }

    // Polimorfismo: Movimento automático do invasor
    atualizar() {
        this.x += this.velocidadeX * this.direcao;
    }

    inverterDirecaoEDescer() {
        this.direcao *= -1;
        this.y += 25; // Desce uma linha
    }
}

// Subclasse Projetil (Herança)
class Projetil extends EntidadeJogo {
    constructor(x, y) {
        super(x, y, 4, 12, '#ffff00');
        this.velocidadeY = 6;
    }

    // Polimorfismo: O projétil viaja sempre para cima
    atualizar() {
        this.y -= this.velocidadeY;
    }
}

// ---------------------------------------------------------
// INSTANCIAÇÃO E LÓGICA DO JOGO (Objetos)
// ---------------------------------------------------------

const jogador = new Jogador(canvas.width / 2 - 15, canvas.height - 50);
let inimigos = [];
let projeteis = [];

// Função para criar a grelha inicial de invasores
function inicializarInimigos() {
    for (let linha = 0; linha < 4; linha++) {
        for (let col = 0; col < 7; col++) {
            inimigos.push(new Inimigo(40 * col + 20, 35 * linha + 40));
        }
    }
}
inicializarInimigos();

// Sistema de disparo (Tecla Espaço)
window.addEventListener('keydown', (e) => {
    if (e.code === 'Space') {
        // Cria um novo objeto projétil a partir da posição central da nave
        const posX = jogador.x + jogador.largura / 2 - 2;
        projeteis.push(new Projetil(posX, jogador.y));
    }
});

// Loop de renderização e atualização
function loopJogo() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Atualiza e desenha o jogador
    jogador.atualizar();
    jogador.desenhar(ctx);

    // Atualiza e desenha os projéteis
    projeteis.forEach((projetil, index) => {
        projetil.atualizar();
        projetil.desenhar(ctx);
        
        // Remove o projétil se sair do topo do ecrã
        if (projetil.y < 0) {
            projeteis.splice(index, 1);
        }
    });

    // Atualiza e desenha os inimigos, verificando colisões com as bordas
    let tocouBorda = false;
    inimigos.forEach(inimigo => {
        inimigo.atualizar();
        inimigo.desenhar(ctx);
        if (inimigo.x <= 0 || inimigo.x + inimigo.largura >= canvas.width) {
            tocouBorda = true;
        }
    });

    // Se algum inimigo tocar na borda, inverte a direção de toda a armada
    if (tocouBorda) {
        inimigos.forEach(inimigo => inimigo.inverterDirecaoEDescer());
    }

    // Deteção Simples de Colisão (Projétil vs Inimigo)
    projeteis.forEach((projetil, pIndex) => {
        inimigos.forEach((inimigo, iIndex) => {
            if (
                projetil.x < inimigo.x + inimigo.largura &&
                projetil.x + projetil.largura > inimigo.x &&
                projetil.y < inimigo.y + inimigo.altura &&
                projetil.altura + projetil.y > inimigo.y
            ) {
                // Remove o inimigo e o projétil aquando da colisão
                inimigos.splice(iIndex, 1);
                projeteis.splice(pIndex, 1);
            }
        });
    });

    // Requisita o próximo frame
    requestAnimationFrame(loopJogo);
}

// Inicia o jogo
loopJogo();
