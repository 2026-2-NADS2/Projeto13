// Som: toca os efeitos sonoros do jogo.
// Os sons são SINTETIZADOS na hora com a Web Audio API (osciladores e ruído),
// por isso não há arquivos de áudio nem direitos autorais de terceiros.
// Os navegadores só liberam o áudio depois de um clique ou tecla do jogador;
// por isso o Jogo chama ativar() quando a partida começa.
class Som {
  constructor() {
    this.contexto = null; // AudioContext, criado só quando o jogador interage
    this.mestre = null;   // controle de volume geral
    this.ligado = true;
    this.volume = 0.6;
    this.ultimoTiroInimigo = -1; // para não tocar o som de tiro inimigo mais de ~7 vezes por segundo
  }

  // Cria (ou retoma) o sistema de áudio do navegador.
  // Devolve uma Promise com o estado final: 'running' = som liberado; qualquer outro
  // valor ('suspended', 'sem-suporte'...) = o navegador ainda não deixou tocar.
  ativar() {
    if (!this.contexto) {
      const ContextoDeAudio = window.AudioContext || window.webkitAudioContext;
      if (!ContextoDeAudio) return Promise.resolve('sem-suporte'); // o jogo segue sem som
      try {
        this.contexto = new ContextoDeAudio();
      } catch (erro) {
        return Promise.resolve('erro');
      }
      this.mestre = this.contexto.createGain();
      this.mestre.gain.value = this.volume;
      // O compressor evita estalos quando vários sons tocam ao mesmo tempo
      const compressor = this.contexto.createDynamicsCompressor();
      this.mestre.connect(compressor);
      compressor.connect(this.contexto.destination);
      this._destravar();
    }
    if (this.contexto.state === 'suspended') {
      return this.contexto.resume().then(() => this.contexto.state).catch(() => 'suspended');
    }
    return Promise.resolve(this.contexto.state);
  }

  // Toca 1 amostra de silêncio: alguns navegadores (como o Safari do iPhone)
  // só liberam o áudio depois que algo "toca" dentro de um clique ou toque.
  _destravar() {
    const silencio = this.contexto.createBuffer(1, 1, 22050);
    const fonte = this.contexto.createBufferSource();
    fonte.buffer = silencio;
    fonte.connect(this.contexto.destination);
    fonte.start(0);
  }

  // Liga/desliga o som. Devolve o novo estado (true = ligado).
  alternar() {
    this.ligado = !this.ligado;
    return this.ligado;
  }

  // Toca um tom que desliza de uma frequência para outra (em Hz).
  // tipo: formato da onda ('square', 'sawtooth', 'triangle'...) | atraso: segundos até tocar
  _tom(tipo, freqInicial, freqFinal, duracao, ganho = 1, atraso = 0) {
    if (!this.ligado || !this.contexto) return;

    const inicio = this.contexto.currentTime + atraso;
    const oscilador = this.contexto.createOscillator();
    const volume = this.contexto.createGain();

    oscilador.type = tipo;
    oscilador.frequency.setValueAtTime(freqInicial, inicio);
    oscilador.frequency.exponentialRampToValueAtTime(Math.max(freqFinal, 1), inicio + duracao);
    volume.gain.setValueAtTime(ganho, inicio);
    volume.gain.exponentialRampToValueAtTime(0.001, inicio + duracao);

    oscilador.connect(volume);
    volume.connect(this.mestre);
    oscilador.start(inicio);
    oscilador.stop(inicio + duracao);
  }

  // Toca ruído (chiado) que some aos poucos: base das explosões.
  _ruido(duracao, ganho = 1) {
    if (!this.ligado || !this.contexto) return;

    const ctx = this.contexto;
    const amostras = Math.floor(ctx.sampleRate * duracao);
    const buffer = ctx.createBuffer(1, amostras, ctx.sampleRate);
    const dados = buffer.getChannelData(0);
    for (let i = 0; i < amostras; i++) dados[i] = Math.random() * 2 - 1;

    const fonte = ctx.createBufferSource();
    fonte.buffer = buffer;
    const filtro = ctx.createBiquadFilter(); // corta os agudos para o ruído soar mais "grave"
    filtro.type = 'lowpass';
    filtro.frequency.value = 1200;
    const volume = ctx.createGain();
    volume.gain.setValueAtTime(ganho, ctx.currentTime);
    volume.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duracao);

    fonte.connect(filtro);
    filtro.connect(volume);
    volume.connect(this.mestre);
    fonte.start();
  }

  // ---- Efeitos do jogo (cada um é uma combinação de tons e ruído) ----

  tiroJogador() { this._tom('square', 900, 200, 0.12, 0.5); }

  tiroInimigo() {
    if (!this.contexto || this.contexto.currentTime - this.ultimoTiroInimigo < 0.14) return;
    this.ultimoTiroInimigo = this.contexto.currentTime;
    this._tom('sawtooth', 320, 110, 0.15, 0.5);
  }

  explosao() {
    this._ruido(0.25, 0.8);
    this._tom('sawtooth', 180, 40, 0.25, 0.5);
  }

  jogadorAtingido() {
    this._ruido(0.5, 1);
    this._tom('sawtooth', 240, 30, 0.5, 0.6);
  }

  // "Marcha" dos invasores: 4 notas graves que se repetem.
  passo(indice) {
    const notas = [130, 116, 103, 98];
    const nota = notas[indice % notas.length];
    // Onda quadrada: tem harmônicos mais agudos, que os alto-falantes pequenos conseguem reproduzir
    this._tom('square', nota, nota, 0.09, 0.5);
  }

  novoNivel() {
    [440, 554, 659].forEach((nota, i) => this._tom('square', nota, nota, 0.14, 0.7, i * 0.12));
  }

  pausa() { this._tom('square', 330, 330, 0.08, 0.6); }

  vitoria() {
    [523, 659, 784, 659, 784, 1047].forEach((nota, i) => this._tom('square', nota, nota, 0.18, 0.4, i * 0.15));
  }

  derrota() {
    [392, 330, 262, 196].forEach((nota, i) => this._tom('sawtooth', nota, nota * 0.9, 0.3, 0.4, i * 0.25));
  }
}
