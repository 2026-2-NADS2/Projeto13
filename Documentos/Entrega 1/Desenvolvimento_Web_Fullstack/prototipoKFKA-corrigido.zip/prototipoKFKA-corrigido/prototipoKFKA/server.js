// ============================================================
// KFKA - Plataforma de Acompanhamento Escolar
// Arquivo: server.js
// Descrição: ponto de entrada do backend. Cria o servidor Express,
// entrega as páginas do front-end (pasta public), define as rotas
// da API e trata endereços inexistentes (erro 404).
// Para iniciar: node server.js
// ============================================================

// Importa o módulo "path", que já vem com o Node.js. Ele monta
// caminhos de arquivos do jeito certo em qualquer sistema
// operacional (Windows usa "\" e Linux/Mac usam "/").
const path = require('path');

// Importa o Express, o framework que cria o servidor web e as rotas.
const express = require('express');

// Importa o pool de conexões com o MySQL, configurado no arquivo db.js.
// "Pool" é um conjunto de conexões reaproveitáveis: em vez de abrir e
// fechar uma conexão a cada consulta, o sistema pega uma livre do pool.
const pool = require('./db');

// Cria a aplicação Express. É nela que registramos as rotas.
const app = express();

// Porta em que o servidor vai "escutar" os pedidos (localhost:3000).
const PORT = 3000;

// ============================================================
// ARQUIVOS ESTÁTICOS (front-end)
// ============================================================

// Entrega automaticamente os arquivos da pasta "public" (HTML, CSS,
// JS, imagens). Exemplo: um pedido para /html/login/login.html devolve
// o arquivo public/html/login/login.html, sem precisar criar uma rota
// para cada página.
// path.join(__dirname, 'public') monta o caminho completo da pasta
// "public" a partir de onde o server.js está. Assim o site funciona
// mesmo que o comando "node server.js" seja rodado de outra pasta.
app.use(express.static(path.join(__dirname, 'public')));

// Abrir http://localhost:3000/ leva direto para a tela de login.
app.get('/', (req, res) => {
  res.redirect('/html/login/login.html');
});

// ============================================================
// ROTAS DA API
// ============================================================

// Rota de teste: confirma se o servidor consegue falar com o banco.
// "async" permite usar "await" para esperar a resposta do MySQL
// sem travar o servidor.
app.get('/teste-db', async (req, res) => {
  try {
    // Conta quantos registros existem na tabela usuario.
    // O resultado vem como [linhas, colunas]; pegamos só as linhas.
    const [rows] = await pool.query('SELECT COUNT(*) AS total FROM usuario');

    // Responde em JSON dizendo que a conexão funcionou e o total encontrado.
    res.json({ conectado: true, total_usuarios: rows[0].total });
  } catch (erro) {
    // Se algo falhar (banco desligado, senha errada no .env etc.),
    // responde com status 500 (erro interno do servidor).
    // Observação: mostrar erro.message é aceitável só nesta rota de
    // teste; em rotas reais isso pode expor detalhes do banco.
    res.status(500).json({ conectado: false, erro: erro.message });
  }
});

// ============================================================
// FUNÇÃO AUXILIAR: lerInteiro
// Os filtros chegam na URL SEMPRE como texto (ex.: "?bimestre=3"
// chega como a string "3"). Esta função converte para número inteiro
// e confere se está dentro do intervalo permitido.
// Devolve:
//   - null      -> o filtro não foi enviado (sem filtro);
//   - um número -> valor válido;
//   - NaN       -> valor inválido (a rota responde erro 400).
// ============================================================
function lerInteiro(valor, minimo, maximo) {
  // Filtro ausente ou vazio ("?bimestre=") = sem filtro.
  if (valor === undefined || valor === '') return null;

  // Number("3") -> 3; Number("abc") -> NaN; Number("2.5") -> 2.5
  const numero = Number(valor);

  // Number.isInteger descarta NaN e números quebrados (2.5).
  if (!Number.isInteger(numero) || numero < minimo || numero > maximo) {
    return NaN;
  }
  return numero;
}

// ============================================================
// GET /api/relatorios
// Lista os relatórios PUBLICADOS, com filtros e paginação.
// Usada pela página html/responsavel/responsavel_relatorios_filtro.html (tabela
// "tabela-relatorios") e pelos "relatórios recentes" do início.
//
// Filtros opcionais na URL (query string):
//   ?aluno=1          -> id do aluno
//   &ano_letivo=2026  -> ano letivo
//   &bimestre=3       -> número do bimestre (1 a 4)
//   &disciplina=Matemática -> nome da disciplina
//   &pagina=2         -> página de resultados (padrão: 1)
// Exemplo: /api/relatorios?aluno=1&bimestre=3&pagina=1
//
// Lê a VIEW vw_relatorio_publicado do schema.sql, que já faz o JOIN
// das 6 tabelas e só traz registros com status = 'publicado'.
//
// ATENÇÃO (segurança/LGPD, para a E2): hoje ainda não existe login
// com sessão, então esta rota devolve relatórios de TODOS os alunos.
// Quando houver sessão, ela deve devolver apenas os alunos vinculados
// ao responsável logado (tabela aluno_responsavel). Sem isso, um pai
// conseguiria ver relatórios dos filhos de outras famílias.
// ============================================================
app.get('/api/relatorios', async (req, res) => {
  // Quantos relatórios por página. Trazer tudo de uma vez deixaria o
  // sistema lento quando houver muitos registros (requisito de
  // desempenho do PI: paginação).
  const POR_PAGINA = 10;

  // ---------- 1. Ler e validar os filtros ----------
  const aluno = lerInteiro(req.query.aluno, 1, 2147483647);
  const anoLetivo = lerInteiro(req.query.ano_letivo, 2000, 2100);
  const bimestre = lerInteiro(req.query.bimestre, 1, 4);
  const pagina = lerInteiro(req.query.pagina, 1, 100000) ?? 1; // ?? = "se for null, use 1"

  // Disciplina é texto: tiramos espaços das pontas e limitamos o tamanho
  // (mesmo limite da coluna disciplina.nome no banco: 100).
  const disciplina = typeof req.query.disciplina === 'string'
    ? req.query.disciplina.trim().slice(0, 100)
    : '';

  // Algum filtro numérico veio inválido? Responde 400 (erro do cliente)
  // com uma mensagem clara, em vez de deixar o banco dar erro.
  if ([aluno, anoLetivo, bimestre, pagina].some(Number.isNaN)) {
    return res.status(400).json({
      erro: 'Filtro inválido. Verifique aluno, ano letivo, bimestre (1 a 4) e página.',
    });
  }

  // ---------- 2. Montar o WHERE só com os filtros enviados ----------
  // "condicoes" guarda os pedaços do WHERE; "valores" guarda os dados,
  // na mesma ordem dos "?". O mysql2 troca cada "?" pelo valor com
  // segurança: isso impede SQL Injection. NUNCA junte o valor do
  // usuário direto no texto do SQL.
  const condicoes = [];
  const valores = [];

  if (aluno !== null) {
    condicoes.push('aluno_id = ?');
    valores.push(aluno);
  }
  if (anoLetivo !== null) {
    condicoes.push('ano_letivo = ?');
    valores.push(anoLetivo);
  }
  if (bimestre !== null) {
    condicoes.push('bimestre_numero = ?');
    valores.push(bimestre);
  }
  if (disciplina !== '') {
    condicoes.push('disciplina_nome = ?');
    valores.push(disciplina);
  }

  // Sem nenhum filtro, o WHERE fica vazio e a consulta traz tudo.
  const where = condicoes.length > 0 ? 'WHERE ' + condicoes.join(' AND ') : '';

  try {
    // ---------- 3. Contar o total (para a paginação) ----------
    // O front precisa saber quantas páginas existem para escrever
    // "Página 1 de 3" e desabilitar o botão "Próxima" na última.
    const [contagem] = await pool.query(
      `SELECT COUNT(*) AS total FROM vw_relatorio_publicado ${where}`,
      valores
    );
    const total = contagem[0].total;
    const totalPaginas = Math.max(1, Math.ceil(total / POR_PAGINA));

    // ---------- 4. Buscar só a página pedida ----------
    // LIMIT = quantos trazer; OFFSET = quantos pular.
    // Página 1 pula 0, página 2 pula 10, página 3 pula 20...
    const offset = (pagina - 1) * POR_PAGINA;

    // Minimização de dados (LGPD): a lista NÃO traz a "descricao"
    // (o texto completo do professor). Ela só é necessária na página
    // de detalhe, que buscará um relatório por vez.
    const [linhas] = await pool.query(
      `SELECT acompanhamento_id, aluno_id, aluno_nome, turma_nome,
              disciplina_nome, professor_nome, bimestre_numero,
              ano_letivo, media, publicado_em
         FROM vw_relatorio_publicado
         ${where}
        ORDER BY publicado_em DESC, acompanhamento_id DESC
        LIMIT ? OFFSET ?`,
      [...valores, POR_PAGINA, offset] // "..." copia os valores dos filtros e acrescenta LIMIT e OFFSET
    );

    // ---------- 5. Responder em JSON ----------
    // Formato pensado para o front: os dados da paginação + a lista.
    return res.json({
      pagina,
      porPagina: POR_PAGINA,
      total,
      totalPaginas,
      relatorios: linhas.map((linha) => ({
        id: linha.acompanhamento_id,
        alunoId: linha.aluno_id,
        aluno: linha.aluno_nome,
        turma: linha.turma_nome,
        disciplina: linha.disciplina_nome,
        professor: linha.professor_nome,
        bimestre: linha.bimestre_numero,
        anoLetivo: linha.ano_letivo,
        // DECIMAL chega do mysql2 como texto ("8.50"); Number converte para 8.5.
        media: Number(linha.media),
        publicadoEm: linha.publicado_em,
      })),
    });
  } catch (erro) {
    // O detalhe técnico vai só para o terminal; o usuário recebe uma
    // mensagem genérica (mostrar erro.message poderia expor nomes de
    // tabelas e colunas do banco).
    console.error('Erro em GET /api/relatorios:', erro);
    return res.status(500).json({ erro: 'Não foi possível carregar os relatórios. Tente novamente.' });
  }
});

// ============================================================
// TRATAMENTO DE ROTA INEXISTENTE (404)
// IMPORTANTE: estes dois blocos precisam ficar DEPOIS de todas as
// outras rotas e do express.static. O Express testa as rotas na
// ordem em que foram escritas; se o pedido chegou até aqui, é
// porque nenhuma rota anterior atendeu, ou seja, o endereço não existe.
// Toda rota nova deve ser escrita ACIMA deste bloco.
// ============================================================

// 404 da API: quem chama /api/... é o JavaScript (fetch), que espera
// JSON. Por isso respondemos em JSON, e não com a página HTML.
app.use('/api', (req, res) => {
  res.status(404).json({ erro: 'Rota da API não encontrada.' });
});

// 404 das páginas: qualquer outro endereço inexistente recebe o 404.html.
// res.status(404) é essencial: sem ele, o navegador receberia o código
// 200 ("deu tudo certo") mesmo mostrando uma página de erro.
// path.join monta o caminho completo do arquivo; __dirname é a pasta
// onde este server.js está.
app.use((req, res) => {
  res.status(404).sendFile(path.join(__dirname, 'public', 'html', 'erro404', '404.html'));
});

// ============================================================
// INICIALIZAÇÃO
// ============================================================

// Liga o servidor na porta definida e mostra o endereço no terminal.
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
