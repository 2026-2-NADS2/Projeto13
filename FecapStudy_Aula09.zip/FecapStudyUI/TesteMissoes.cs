using System;
using System.Collections.Generic;
using System.Text;

namespace FecapStudyUI;

// =====================================================================
// Testes de mesa das Missões 1 a 8 (o "programa principal" de cada missão).
// A tela chama TesteMissoes.Executar() no botão "Rodar testes" e mostra o texto.
// =====================================================================
public static class TesteMissoes
{
    public static string Executar()
    {
        StringBuilder log = new StringBuilder();

        // ---------------- MISSÃO 1 ----------------
        log.AppendLine("===== MISSÃO 1 — Disciplinas =====");
        Disciplina poo = new Disciplina("ADS201", "Programação Orientada a Objetos", "Computação", 4);
        Disciplina bd = new Disciplina("ADS202", "Banco de Dados", "Dados", 3);
        Disciplina pi = new Disciplina("ADS203", "Projeto Interdisciplinar", "Projetos", -4);
        log.AppendLine(poo.ExibirResumo());
        log.AppendLine(bd.ExibirResumo());
        log.AppendLine(pi.ExibirResumo() + "   <- passou -4h e virou 2h");

        // ---------------- MISSÃO 2 ----------------
        log.AppendLine();
        log.AppendLine("===== MISSÃO 2 — Encapsulamento da Meta =====");
        MetaEstudo meta = new MetaEstudo(100);
        log.AppendLine("RegistrarAvanco(-20): " + meta.RegistrarAvanco(-20));
        log.AppendLine("RegistrarAvanco(900): " + meta.RegistrarAvanco(900));
        log.AppendLine("Minutos cumpridos (deve ser 0): " + meta.GetMinutosCumpridos());
        log.AppendLine("RegistrarAvanco(60): " + meta.RegistrarAvanco(60));
        log.AppendLine($"Percentual (deve ser 60%): {meta.CalcularPercentual():F1}%");
        log.AppendLine("Meta cumprida? " + meta.EstaCumprida());
        MetaEstudo metaBaixa = new MetaEstudo(5);
        log.AppendLine("Meta de 5 min ajustada para: " + metaBaixa.GetMetaMinutosSemana());

        // ---------------- MISSÃO 3 ----------------
        log.AppendLine();
        log.AppendLine("===== MISSÃO 3 — Perfis (classe abstrata) =====");
        Administrador admin = new Administrador(1, "Profa. Helena", "helena@fecap.br", "adm123", "Coordenação PI");
        Responsavel resp = new Responsavel(2, "Carlos Silva", "carlos@email.com", "pai123", "Pai");
        Discente lucas = new Discente(3, "Lucas Silva", "lucas@fecap.br", "luc123", "RA-101");
        List<Usuario> usuarios = new List<Usuario> { admin, resp, lucas };
        foreach (Usuario u in usuarios)
            log.AppendLine(u.ObterTipoPerfil() + " -> " + u.GerarPainelResumo());
        log.AppendLine("Lucas autentica com 'luc123'? " + lucas.Autenticar("luc123"));
        log.AppendLine("Lucas autentica com 'errada'? " + lucas.Autenticar("errada"));

        // ---------------- MISSÃO 4 ----------------
        log.AppendLine();
        log.AppendLine("===== MISSÃO 4 — Polimorfismo Dinâmico =====");
        List<SessaoEstudo> sessoes = new List<SessaoEstudo>
        {
            new SessaoPomodoro(poo, 50, 2),
            new SessaoExercicios(bd, 30, 10, 8),
            new SessaoLeitura(pi, 40, 20, true)
        };
        int xpTotal = 0;
        foreach (SessaoEstudo s in sessoes)   // nenhum if testando o tipo!
        {
            log.AppendLine(s.GerarFeedback());
            xpTotal += s.CalcularXp();
        }
        log.AppendLine("XP total da lista: " + xpTotal);

        // ---------------- MISSÃO 5 ----------------
        log.AppendLine();
        log.AppendLine("===== MISSÃO 5 — Sobrecarga de RegistrarEstudo =====");
        lucas.RegistrarEstudo(sessoes[1]);                 // Forma 1: sessão pronta
        log.AppendLine("Forma 1 (sessão pronta)   -> " + lucas.GerarPainelResumo());
        lucas.RegistrarEstudo(poo, 60);                    // Forma 2: atalho Pomodoro
        log.AppendLine("Forma 2 (disciplina, min) -> " + lucas.GerarPainelResumo());
        lucas.RegistrarEstudo(pi, 14, 16, 30);             // Forma 3: por horário
        log.AppendLine("Forma 3 (por horário)     -> " + lucas.GerarPainelResumo());
        foreach (SessaoEstudo s in lucas.GetHistorico())
            log.AppendLine("   " + s.GerarFeedback());

        // ---------------- MISSÃO 6 ----------------
        log.AppendLine();
        log.AppendLine("===== MISSÃO 6 — Interfaces =====");
        List<INotificador> canais = new List<INotificador>
        {
            new NotificadorEmail(), new NotificadorWhatsApp(), new NotificadorPainel()
        };
        foreach (INotificador n in canais)
            log.AppendLine(n.ObterCanal() + " enviou? " + n.EnviarAlerta(resp.GetEmail(), "Teste de alerta"));
        log.AppendLine("E-mail para 'semarroba' enviou? " + new NotificadorEmail().EnviarAlerta("semarroba", "x"));
        List<IExportavelJson> exportaveis = new List<IExportavelJson> { sessoes[0], meta, lucas };
        foreach (IExportavelJson e in exportaveis)
            log.AppendLine(e.ParaJson());

        // ---------------- MISSÃO 7 ----------------
        log.AppendLine();
        log.AppendLine("===== MISSÃO 7 — Associação e Agregação =====");
        log.AppendLine("Vincular Lucas: " + resp.VincularDiscente(lucas));
        log.AppendLine("Vincular Lucas de novo (não duplica): " + resp.VincularDiscente(lucas));
        log.AppendLine(resp.GerarPainelResumo());
        TrilhaEstudo trilha2 = new TrilhaEstudo("Trilha 2º Semestre ADS", admin);
        trilha2.AdicionarDisciplina(poo);
        trilha2.AdicionarDisciplina(bd);
        trilha2.AdicionarDisciplina(pi);
        TrilhaEstudo trilhaReforco = new TrilhaEstudo("Trilha de Reforço", admin);
        trilhaReforco.AdicionarDisciplina(poo);   // a MESMA disciplina em outra trilha
        log.AppendLine(trilha2.ExibirResumo());
        log.AppendLine(trilhaReforco.ExibirResumo());

        // ---------------- MISSÃO 8 ----------------
        log.AppendLine();
        log.AppendLine("===== MISSÃO 8 — Composição e Dependência =====");
        PlanoEstudo plano = new PlanoEstudo("Plano do Lucas");
        plano.AdicionarItem("Segunda", 60);
        plano.AdicionarItem("Quarta", 90);
        plano.AdicionarItem("Sábado", 120);
        foreach (string linha in plano.ListarItens())
            log.AppendLine("   " + linha);
        log.AppendLine("Total planejado: " + plano.CalcularTotalPlanejado() + " min");

        MetaEstudo metaLucas = resp.DefinirMeta(lucas, 200);
        metaLucas.RegistrarAvanco(120);
        ServicoAlertaResponsavel servico = new ServicoAlertaResponsavel();
        log.AppendLine(servico.AvaliarDiscente(lucas, metaLucas, resp, new NotificadorEmail()));
        metaLucas.RegistrarAvanco(90);
        log.AppendLine(servico.AvaliarDiscente(lucas, metaLucas, resp, new NotificadorWhatsApp()));

        log.AppendLine();
        log.AppendLine("===== FIM DOS TESTES =====");
        return log.ToString();
    }
}
